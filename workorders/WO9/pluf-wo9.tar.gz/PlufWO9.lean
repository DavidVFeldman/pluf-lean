/-
  PlufWO9.lean — Work Order 9 for the pluf project (Feldman–Wilce).

  Scope: the harvest commission recommended by the WO-7a census. It
  converts probe material into contracted, reusable infrastructure, and
  closes target (d) as a paper-facing statement:
    (A) target (d): Paper I, Proposition 2.3 as printed, in both regimes
        (the triple argument for H from WO-6, the principality argument in
        finite dimension from WO-7a), stated at the paper's generality;
    (B) the essential spectrum layer: `essSpec` and its supporting
        theorems, contracted as a stable API;
    (C) the approximate-eigenvector substitute for spectral subspaces:
        the engine theorem and the closed-span construction that will
        stand in for the Borel functional calculus in Paper I §5;
    (D) the general HilbertBasis block API, superseding the standard-basis
        `PlufWO1.block` / `PlufWO2.block` for the basis-relative work of
        Paper II §6, together with the corrected Q2 and the reindexing
        lemma;
    (E) the ω₁-recursion combinator, with the universe tax factored into
        a lemma.

  All of this exists in `PlufWO7a.lean` as probe material. This work order
  asks for it as a *contracted API*: stable names, minimal hypotheses,
  docstrings stating what each item is for, and no dependence on the probe
  file — `PlufWO7a.lean` remains in the repository as the census record and
  MUST NOT be deleted or edited.

  Ground rules as in WO-1–WO-8, including the codified counterexample
  license. Nothing classical is assumed: CH enters only as a hypothesis
  (an equinumerosity assumption), never as an axiom.

  Base: the WO-7a artifact (CI runs #1–#8; 149 theorems). All prior
  theorems must remain green.

  Toolchain: leanprover/lean4:v4.28.0, Mathlib pinned as in the repo.
-/
import RequestProject.PlufWO7a

open Set

namespace PlufWO9

/-! ### Part A: target (d) — Paper I, Proposition 2.3, as printed -/

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [CompleteSpace E]

/-- A1 (Paper I, Proposition 2.3, finite-dimensional regime). The lattice
    of subspaces of a real inner-product space of finite dimension at least
    two carries no prime filter. This is `PlufWO7a`'s group D, re-sited with
    the paper's hypotheses and without the unused oddness assumption the
    probe retained. -/
theorem no_prime_filter_finrank (V : Type*) [NormedAddCommGroup V]
    [InnerProductSpace ℝ V] [FiniteDimensional ℝ V]
    (h2 : 2 ≤ Module.finrank ℝ V)
    (π : Set (Submodule ℝ V)) (hne : π.Nonempty)
    (hup : ∀ M ∈ π, ∀ N : Submodule ℝ V, M ≤ N → N ∈ π)
    (hinf : ∀ M ∈ π, ∀ N ∈ π, M ⊓ N ∈ π)
    (hbot : (⊥ : Submodule ℝ V) ∉ π) :
    ¬ (∀ M N : Submodule ℝ V, M ⊔ N ∈ π → M ∈ π ∨ N ∈ π) := by
  sorry

/-- A2 (Paper I, Proposition 2.3, the statement the paper makes). Combining
    A1 with WO-6's `no_prime_filter` for `PlufWO1.H`: no proper filter of
    closed subspaces of the separable infinite-dimensional space is prime,
    and no proper filter of subspaces of a finite-dimensional space of
    dimension at least two is prime. Package the two regimes in whatever
    single statement is honest — a disjunction on `FiniteDimensional`, or
    two named corollaries — and REPORT the packaging. Do not claim a
    uniform statement covering infinite-dimensional non-separable spaces
    unless the triple construction is carried out there as well (it should
    generalize: pair up any orthonormal basis; if that is cheap, prove it
    and report). -/
theorem no_prime_filter_paper (π : Set (Submodule ℝ PlufWO1.H))
    (hcl : ∀ M ∈ π, IsClosed (M : Set PlufWO1.H)) (hne : π.Nonempty)
    (hup : ∀ M ∈ π, ∀ N : Submodule ℝ PlufWO1.H,
      IsClosed (N : Set PlufWO1.H) → M ≤ N → N ∈ π)
    (hinf : ∀ M ∈ π, ∀ N ∈ π, M ⊓ N ∈ π)
    (hbot : (⊥ : Submodule ℝ PlufWO1.H) ∉ π) :
    ¬ (∀ M N : Submodule ℝ PlufWO1.H, IsClosed (M : Set PlufWO1.H) →
        IsClosed (N : Set PlufWO1.H) →
        (M ⊔ N).topologicalClosure ∈ π → M ∈ π ∨ N ∈ π) := by
  sorry

/-! ### Part B: the essential spectrum layer -/

/-- B0. The essential spectrum, by the Weyl-sequence definition installed
    in the census (Mathlib has no essential spectrum, no Calkin algebra and
    no Fredholm theory). Re-site the probe definition here as the stable
    name; `PlufWO7a.essSpec` may be re-exported or redefined, prover's
    choice, reported. -/
def essSpec (T : E →L[ℝ] E) : Set ℝ := sorry

/-- B1. The essential spectrum is closed (probe P2). -/
theorem isClosed_essSpec (T : E →L[ℝ] E) : IsClosed (essSpec T) := by
  sorry

/-- B2 (probe P3, the load-bearing item). Passing to a closed subspace of
    finite codimension does not shrink the essential spectrum. The census
    reports this needs neither self-adjointness nor the finite-rank/Calkin
    argument the paper uses; state it with the minimal hypotheses found and
    REPORT what they are. -/
theorem essSpec_le_of_finCodim (T : E →L[ℝ] E) (V : Submodule ℝ E)
    (hV : IsClosed (V : Set E)) (hfc : Module.Finite ℝ ↥Vᗮ) :
    True := by
  sorry

/-- B3 (probe P4). Weakly null sequences have vanishing projections onto
    finite-dimensional subspaces. -/
theorem tendsto_norm_proj_finiteDimensional_of_weaklyNull : True := by
  sorry

/-! ### Part C: the substitute for spectral subspaces -/

/-- C1 (the engine). From a bounded operator and a point of the essential
    spectrum, an orthonormal sequence of approximate eigenvectors with
    prescribed rapid decay of the defects. This is the census's replacement
    for the Borel functional calculus, and the single largest cost saving
    it found. State it so that the decay rate is a parameter (a summable
    or geometric sequence supplied by the caller), since Paper I §5's
    escape and blocking arguments choose the rate. -/
theorem exists_orthonormal_approx_eigenvectors (T : E →L[ℝ] E) (lam : ℝ)
    (hlam : lam ∈ essSpec T) (ε : ℕ → ℝ) (hε : ∀ n, 0 < ε n) :
    ∃ u : ℕ → E, Orthonormal ℝ u ∧ ∀ n, ‖T (u n) - lam • u n‖ < ε n := by
  sorry

/-- C2 (the substitute subspace). The closed span of such a sequence, with
    the two properties Paper I §5 consumes: it is infinite-dimensional, and
    the compression of `T` to it is within a prescribed tolerance of `lam`
    on unit vectors. Formulate the tolerance clause in whatever form the
    proof supports (a bound depending on the tail of `ε`), and REPORT the
    exact form — Paper I §5's contracts in WO-13/WO-14 will be written
    against it, so its shape matters more than its strength. -/
theorem approx_eigen_span_spec (T : E →L[ℝ] E) (lam : ℝ) (u : ℕ → E)
    (hu : Orthonormal ℝ u) (ε : ℕ → ℝ)
    (hdef : ∀ n, ‖T (u n) - lam • u n‖ < ε n) (hsum : Summable ε) :
    True := by
  sorry

/-! ### Part D: the general HilbertBasis block API -/

section Bases

variable {ι : Type*} (b : HilbertBasis ι ℝ E)

/-- D1. The block of a set of indices relative to an arbitrary Hilbert
    basis: the closed span of the corresponding basis vectors. This
    supersedes the standard-basis `block` of WO-1/WO-2 for the
    basis-relative work of Paper II §6. Provide the coordinate
    characterization (probe Q4) and closedness; then prove that the
    standard-basis instance agrees with `PlufWO1.block`, so that existing
    results transfer without restatement. -/
def blockB (S : Set ι) : Submodule ℝ E := sorry

theorem mem_blockB_iff (S : Set ι) (x : E) :
    x ∈ blockB b S ↔ ∀ i ∉ S, b.repr x i = 0 := by
  sorry

theorem isClosed_blockB (S : Set ι) : IsClosed (blockB b S : Set E) := by
  sorry

/-- D2. Agreement with the standard-basis block of the earlier work orders,
    for the standard basis of `PlufWO1.H`. If the identification requires a
    bridging isometry rather than definitional equality, supply it and
    REPORT. -/
theorem blockB_stdBasis_eq (S : Set ℕ) : True := by
  sorry

/-- D3 (probe Q3). Reindexing a Hilbert basis along an equivalence. -/
theorem hilbertBasis_reindex : True := by
  sorry

/-- D4 (the corrected Q2). A separable Hilbert space, together with a
    countable orthogonal decomposition into closed subspaces, admits a
    Hilbert basis indexed by ℕ adapted to the decomposition — each basis
    vector lying in one summand, and each summand's basis vectors spanning
    it. NOTE: the arbitrary-index form of this statement is FALSE (the
    census formalized a counterexample); the separable/countable form
    below is what Paper II, Proposition 6.1 requires. Do not generalize. -/
theorem exists_countable_hilbertBasis_of_decomposition : True := by
  sorry

end Bases

/-! ### Part E: the ω₁-recursion combinator -/

/-- E1 (probe R1). Under CH — supplied as an equinumerosity hypothesis on
    the type in question, never as an axiom — an enumeration of a set by
    the countable ordinals. State it in the form the recursions of WO-12
    and WO-13 will consume, with the universe lifting the census flagged
    handled inside rather than exposed to callers. -/
theorem exists_enumeration_of_CH : True := by
  sorry

/-- E2 (probe R2, the combinator). Transfinite recursion over the countable
    ordinals producing a chain with a stage-wise property, given a
    successor step that extends any admissible stage. The census reports
    that NO successor/limit case split is needed: state the combinator so
    that callers supply one step function and one invariant, and REPORT the
    final signature — WO-12 and WO-13 are written against it. -/
theorem exists_omega1_chain : True := by
  sorry

/-! ### Axiom audit

The `True`-valued placeholders above mark items whose contracted statement
is to be supplied by the prover from the probe material (the census already
proved each; what this commission fixes is the API). For each such item,
REPLACE the placeholder with the real statement, prove it, and audit it
under the name given. Report every signature chosen. -/

#print axioms no_prime_filter_finrank
#print axioms no_prime_filter_paper
#print axioms isClosed_essSpec
#print axioms exists_orthonormal_approx_eigenvectors
#print axioms mem_blockB_iff
#print axioms isClosed_blockB

end PlufWO9
