/-
  PlufWO13.lean — Work Order 13 for the pluf project (Feldman–Wilce).

  Scope: the ZFC lemmas of Paper I, Section 5 — everything before the
  blocking lemma (WO-14) and the CH recursion (WO-15):
    (A) the fixed operator T = diag(1, 1/16, 1, 1/16, …), its spectrum,
        and its essential spectrum;
    (B) ampleness: the definition, the radii lemma (Lemma 5.2), and
        infinite-dimensionality of ample subspaces;
    (C) upward inheritance (Lemma 5.3) and the finite-codimension lemma
        (Lemma 5.4);
    (D) the escape lemma (Lemma 5.5), in the approximate-eigenvector
        formulation that replaces the spectral subspace.

  THE CENTRAL SUBSTITUTION. Paper I §5 is written with the Borel
  functional calculus: the escape lemma produces the spectral subspace
  K^ε_λ(V) = 1_{[λ-ε,λ+ε]}(T_V) V. Mathlib has no Borel functional
  calculus, and the WO-7a census recommended against building one. The
  substitute, proved in WO-9, is the closed span of an orthonormal
  sequence of approximate eigenvectors with summable defects:

    PlufWO9.exists_orthonormal_approx_eigenvectors
    PlufWO9.approx_eigen_span_spec

  whose tolerance clause is homogeneous:
    ∀ x ∈ K, ‖T x - lam • x‖ ≤ (∑' n, ε n) * ‖x‖,
  with infinite-dimensionality delivered as ¬ FiniteDimensional.

  Part D is therefore contracted against that API, not against spectral
  projections. The escaping subspace is an `approxEigenSpan`; the clause
  "λ ∈ σ_ess(T_K)" becomes the homogeneous bound; and "K ∩ N has infinite
  codimension in K" is contracted directly. If the substitution forces a
  change in what the downstream arguments can assume, REPORT it — WO-14
  and WO-15 are written against whatever this commission fixes, and this
  is the interface decision of the commission.

  Base: the WO-10 artifact (181 theorems; CI runs #1–#10). WO-11 runs in
  parallel and is NOT a dependency: nothing here needs cardinal
  arithmetic or CH. All prior theorems must remain green; `PlufWO7a.lean`
  is the census record and is not to be edited.

  Toolchain: leanprover/lean4:v4.28.0, Mathlib pinned as in the repo.
-/
import RequestProject.PlufWO10

open Set

namespace PlufWO13

abbrev H := PlufWO1.H

/-! ### Part A: the operator T -/

/-- A1. The fixed diagonal operator `T = diag(1, 1/16, 1, 1/16, …)`:
    coordinate `n` is scaled by `1` if `n` is even and `1/16` if `n` is
    odd. Contract the operator and its two basic bounds; the diagonal
    entries are `tEntry`. -/
noncomputable def tEntry (n : ℕ) : ℝ := if Even n then 1 else 1/16

noncomputable def T : H →L[ℝ] H := sorry

@[simp] theorem T_evec (n : ℕ) : T (PlufWO1.evec n) = tEntry n • PlufWO1.evec n := by
  sorry

theorem T_selfAdjoint : IsSelfAdjoint T := by
  sorry

/-- A2. The two-sided bound `1/16 ≤ ⟪T x, x⟫ ≤ ‖x‖²`, which is what the
    ampleness arguments use (rather than any spectral statement). State
    in whichever of the quadratic-form or operator-order forms Mathlib
    supports cleanly; report the choice. -/
theorem T_bounds (x : H) :
    (1/16 : ℝ) * ‖x‖^2 ≤ inner (𝕜 := ℝ) (T x) x ∧
      inner (𝕜 := ℝ) (T x) x ≤ ‖x‖^2 := by
  sorry

/-- A3. Both `1` and `1/16` lie in the essential spectrum of `T`: the even
    (resp. odd) basis vectors form an orthonormal, hence weakly null,
    exact eigensequence. (Uses `PlufWO9.essSpec`.) -/
theorem one_mem_essSpec : (1 : ℝ) ∈ PlufWO9.essSpec T := by
  sorry

theorem sixteenth_mem_essSpec : (1/16 : ℝ) ∈ PlufWO9.essSpec T := by
  sorry

/-! ### Part B: ampleness -/

/-- The compression of `T` to a closed subspace. Contract whichever
    rendering WO-9's `essSpec` API consumes — WO-9 supplied an operator
    form `essSpec T ⊆ essSpec (compress T V)`; reuse its `compress` if it
    exists rather than defining a second one, and REPORT. -/
noncomputable def compress (V : Submodule ℝ H) : ↥V →L[ℝ] ↥V := sorry

/-- A nonzero closed subspace is *ample* if both `1` and `1/16` lie in the
    essential spectrum of the compression of `T` to it. -/
def Ample (M : Submodule ℝ H) : Prop :=
  M ≠ ⊥ ∧ IsClosed (M : Set H) ∧
    (1 : ℝ) ∈ PlufWO9.essSpec (compress M) ∧ (1/16 : ℝ) ∈ PlufWO9.essSpec (compress M)

/-- B1 (Lemma 5.2, the consequence actually used). Ample subspaces are
    infinite-dimensional.

    The paper states Lemma 5.2 in terms of the ellipsoid radii
    `m(E ∩ M) = 1`, `M(E ∩ M) = 4`, `r(E ∩ M) = 4`, deducing
    infinite-dimensionality. WO-6 verified the radii lemma
    (`PlufWO6` Part D, both the Rayleigh and ellipsoid forms), so both
    routes are available. Contract the infinite-dimensionality clause,
    which is what §5 consumes; if the radii clauses are cheap on top of
    the WO-6 API, prove them too as B1' and report. -/
theorem infinite_dimensional_of_ample {M : Submodule ℝ H} (hM : Ample M) :
    ¬ FiniteDimensional ℝ ↥M := by
  sorry

/-! ### Part C: inheritance -/

/-- C1 (Lemma 5.3, upward inheritance). For `λ ∈ {1, 1/16}` and closed
    `W ≤ V`: if `λ ∈ σ_ess(T_W)` then `λ ∈ σ_ess(T_V)`. Hence ampleness
    passes upward and its failure passes downward.

    Proof (paper): for `λ = 1`, a weakly null orthonormal `(x k)` in `W`
    with `⟪T x k, x k⟫ → 1` satisfies
    `‖T x k − x k‖² ≤ 2 − 2⟪T x k, x k⟫ → 0` by `0 ≤ T ≤ 1`, so
    `‖T_V x k − x k‖ = ‖P_V (T x k − x k)‖ → 0`. The case `λ = 1/16`
    follows by applying the argument to a rescaled `1 − T`; if that
    rescaling is awkward in Lean, prove the two cases directly — the
    estimate is symmetric — and REPORT. -/
theorem essSpec_compress_mono {W V : Submodule ℝ H}
    (hW : IsClosed (W : Set H)) (hV : IsClosed (V : Set H)) (hWV : W ≤ V)
    {lam : ℝ} (hlam : lam = 1 ∨ lam = 1/16)
    (h : lam ∈ PlufWO9.essSpec (compress W)) :
    lam ∈ PlufWO9.essSpec (compress V) := by
  sorry

theorem ample_of_ample_le {W V : Submodule ℝ H} (hW : Ample W)
    (hV : IsClosed (V : Set H)) (hWV : W ≤ V) : Ample V := by
  sorry

/-- C2 (Lemma 5.4, finite codimension). If `W ≤ V` has finite codimension
    in `V` then the compressions have the same essential spectrum; in
    particular ampleness is inherited by finite-codimension subspaces.

    Paper's proof: `P_V − P_W` has finite rank, so the compressions differ
    by a finite-rank operator. WO-9's B2
    (`essSpec_le_of_finCodim`) supplies one inclusion with minimal
    hypotheses; the other should follow from C1. Report which parts came
    from WO-9 and which are new. -/
theorem essSpec_compress_eq_of_finCodim {W V : Submodule ℝ H}
    (hW : IsClosed (W : Set H)) (hV : IsClosed (V : Set H)) (hWV : W ≤ V)
    (hfc : Module.Finite ℝ (↥V ⧸ (W.comap V.subtype))) :
    PlufWO9.essSpec (compress W) = PlufWO9.essSpec (compress V) := by
  sorry

theorem ample_of_finCodim {W V : Submodule ℝ H} (hV : Ample V)
    (hW : IsClosed (W : Set H)) (hWV : W ≤ V)
    (hfc : Module.Finite ℝ (↥V ⧸ (W.comap V.subtype))) : Ample W := by
  sorry

/-! ### Part D: escape, in the approximate-eigenvector formulation -/

/-- D1 (Lemma 5.5, escape). Let `V` be ample, `N` closed, `V ⊓ N` not
    ample, and `λ ∈ {1, 1/16}` with `λ ∉ σ_ess(T_{V ⊓ N})`. Then for every
    tolerance `δ > 0` there is a closed subspace `K ≤ V` with:
      (i)   `K` infinite-dimensional;
      (ii)  the homogeneous bound `∀ x ∈ K, ‖T x − λ • x‖ ≤ δ * ‖x‖`;
      (iii) `K ⊓ N` of infinite codimension in `K`.

    This replaces the paper's spectral subspace `K^ε_λ(V)` by a WO-9
    `approxEigenSpan`: obtain a weakly null orthonormal approximate
    eigensequence in `V` at `λ` with summable defects of total mass `≤ δ`
    (WO-9 C1, whose decay rate is a caller parameter — take
    `ε n = δ / 2^(n+1)`), and let `K` be its closed span (WO-9 C2 gives
    (i) and (ii)). For (iii): if `K ⊓ N` had finite codimension in `K`,
    then C2 and C1 would put `λ ∈ σ_ess(T_{V ⊓ N})`, contrary to
    hypothesis.

    THE INTERFACE DECISION. WO-14's blocking-lemma recursion works inside
    `K` and needs, at each stage: an infinite-dimensional subspace, a
    quadratic-form estimate for unit vectors of `K`, and enough room to
    impose finitely many linear constraints while staying off `N`. Clause
    (ii) in homogeneous form yields the quadratic-form estimate
    `|⟪T x, x⟫ − λ‖x‖²| ≤ δ‖x‖²` by Cauchy–Schwarz; supply that corollary
    explicitly as D2, since it is what the recursion cites. If any further
    clause is needed to make WO-14 workable, ADD IT HERE and report —
    changing this interface later is expensive. -/
theorem escape {V N : Submodule ℝ H} (hV : Ample V)
    (hN : IsClosed (N : Set H)) (hVN : ¬ Ample (V ⊓ N))
    {lam : ℝ} (hlam : lam = 1 ∨ lam = 1/16)
    (hnot : lam ∉ PlufWO9.essSpec (compress (V ⊓ N)))
    {δ : ℝ} (hδ : 0 < δ) :
    ∃ K : Submodule ℝ H, K ≤ V ∧ IsClosed (K : Set H) ∧
      ¬ FiniteDimensional ℝ ↥K ∧
      (∀ x ∈ K, ‖T x - lam • x‖ ≤ δ * ‖x‖) ∧
      ¬ Module.Finite ℝ (↥K ⧸ ((K ⊓ N).comap K.subtype)) := by
  sorry

/-- D2 (the quadratic-form corollary, for WO-14). On such a `K`,
    `|⟪T x, x⟫ − λ * ‖x‖²| ≤ δ * ‖x‖²`; in particular every unit vector of
    `K` has Rayleigh quotient within `δ` of `λ`. -/
theorem quadratic_estimate_of_bound {K : Submodule ℝ H} {lam δ : ℝ}
    (h : ∀ x ∈ K, ‖T x - lam • x‖ ≤ δ * ‖x‖) (x : H) (hx : x ∈ K) :
    |inner (𝕜 := ℝ) (T x) x - lam * ‖x‖^2| ≤ δ * ‖x‖^2 := by
  sorry

/-- D3 (the corollary the paper draws). Under the hypotheses of D1, `N`
    has infinite codimension in `H`. -/
theorem infinite_codim_of_escape {V N : Submodule ℝ H} (hV : Ample V)
    (hN : IsClosed (N : Set H)) (hVN : ¬ Ample (V ⊓ N))
    {lam : ℝ} (hlam : lam = 1 ∨ lam = 1/16)
    (hnot : lam ∉ PlufWO9.essSpec (compress (V ⊓ N))) :
    ¬ Module.Finite ℝ (H ⧸ N) := by
  sorry

/-! ### Axiom audit -/

#print axioms T_evec
#print axioms T_selfAdjoint
#print axioms T_bounds
#print axioms one_mem_essSpec
#print axioms sixteenth_mem_essSpec
#print axioms infinite_dimensional_of_ample
#print axioms essSpec_compress_mono
#print axioms ample_of_ample_le
#print axioms essSpec_compress_eq_of_finCodim
#print axioms ample_of_finCodim
#print axioms escape
#print axioms quadratic_estimate_of_bound
#print axioms infinite_codim_of_escape

end PlufWO13
