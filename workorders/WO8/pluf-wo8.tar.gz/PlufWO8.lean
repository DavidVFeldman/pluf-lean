/-
  PlufWO8.lean — Work Order 8 for the pluf project (Feldman–Wilce).

  Scope: the state-theoretic sections of Paper III, and the Paper I §6
  residue:
    (A) the ultrafilter-limit state φ_U on the bounded operators of
        ℓ²(κ): that it is a state, its value on projections, and the
        diagonal formula;
    (B) singularity: φ_U annihilates the rank-one projections, hence the
        compacts, by κ-completeness against countable supports;
    (C) countable additivity of φ_U (Paper III, Theorem 4.1), and the
        <κ-additive strengthening in the generic index form used
        throughout this project;
    (D) purity of φ_U, obtained from WO-6's face machinery rather than
        assumed: the face of Φ(U) is a singleton and φ_U belongs to it;
    (E) Theorem 4.2 (countably additive pure states give plufs),
        parametrized by the Blecher–Weaver package — regularity,
        σ-filtration of the 1-set, excision, and determination by the
        1-set — supplied as named hypotheses, so the theorem is ZFC;
    (F) the nonprincipality clause and the Paper I §6 restatement.

  Quarantined classical imports, as named hypotheses only: the
  Blecher–Weaver excision/regularity package (Part E). Nothing else.
  Marcus–Spielman–Srivastava does NOT appear: the point of Paper III §4 is
  that the existence statements avoid it.

  Base: the WO-6 artifact (CI runs #1–#6 green, 115 theorems). Reuse
  PlufWO1–PlufWO6 freely — in particular `PlufWO2.{Hk, evec, block,
  supp, countable_supp}`, `PlufWO3.{PhiU, exists_ulim, PhiU_decides,
  PhiU_nonprincipal}`, `PlufWO6.{IsState, stateFace, face_nonempty,
  face_iff_sandwich, rsp_all_iff_face_subsingleton, maximality_criterion,
  principal_of_finiteDimensional}`, and `PlufWO6.States` API
  (`IsState.mono`, `IsState.compress`, `IsState.starProjection_le_one`).
  All 115 prior theorems must remain green.

  NOTE ON SCALARS. The project works over ℝ. Paper III's §§4–5 are stated
  over ℂ in the literature; the arguments contracted here are
  scalar-agnostic (they use only positivity, the quadratic form, and
  countable/κ-completeness). Report if any item genuinely needs ℂ.

  Toolchain: leanprover/lean4:v4.28.0, Mathlib pinned as in the repo.
-/
import RequestProject.PlufWO6

open Set PlufWO2 PlufWO3 PlufWO6

namespace PlufWO8

variable {κ : Type*} [LinearOrder κ]

/-! ### Part A: the ultrafilter-limit state -/

/-- A1. The diagonal function of a bounded operator is bounded, so its
    U-limit exists (WO-3's `exists_ulim` with `CountablyComplete`, or
    directly by compactness of an interval). Contract: the limit
    functional, together with its defining property. -/
noncomputable def phiLim (U : Ultrafilter κ) (hcc : PlufWO3.CountablyComplete U)
    (T : Hk κ →L[ℝ] Hk κ) : ℝ :=
  sorry

theorem phiLim_spec (U : Ultrafilter κ) (hcc : PlufWO3.CountablyComplete U)
    (T : Hk κ →L[ℝ] Hk κ) :
    ∀ ε > 0, {α | |inner (𝕜 := ℝ) (T (evec α)) (evec α) - phiLim U hcc T| ≤ ε} ∈ U := by
  sorry

/-- A2. `phiLim` is a state in the sense of WO-6 (`PlufWO6.IsState`):
    linear and continuous in `T`, nonnegative on operators with
    nonnegative quadratic form, and `1` at the identity. Linearity and
    continuity are the standard properties of ultrafilter limits; the
    continuity bound is `|φ T| ≤ ‖T‖`. Package as a
    `(Hk κ →L[ℝ] Hk κ) →L[ℝ] ℝ` and prove `IsState` of it; the bundling
    is the prover's choice, reported. -/
theorem isState_phiLim (U : Ultrafilter κ) (hcc : PlufWO3.CountablyComplete U) :
    ∃ φ : (Hk κ →L[ℝ] Hk κ) →L[ℝ] ℝ, PlufWO6.IsState φ ∧
      ∀ T, φ T = phiLim U hcc T := by
  sorry

/-! ### Part B: singularity -/

/-- B1. For a unit vector `v`, the diagonal of the rank-one projection
    onto `ℝ ∙ v` is `α ↦ ⟪v, evec α⟫²`, nonzero for only countably many
    `α` (countable support of `v`, `PlufWO2.countable_supp`). With
    `CountableSmall`, the U-limit is `0`. -/
theorem phiLim_rankOne_eq_zero (U : Ultrafilter κ)
    (hcc : PlufWO3.CountablyComplete U)
    (hsmall : PlufWO2.CountableSmall U) (v : Hk κ) :
    phiLim U hcc ((ℝ ∙ v).starProjection) = 0 := by
  sorry

/-- B2 (singularity, finite-rank form). `phiLim` annihilates every
    projection onto a finite-dimensional subspace. (The paper says
    "vanishes on the compacts"; the finite-rank statement is what the
    argument gives directly, and it suffices for the nonprincipality use
    in Part F. If the full compact-operator statement is cheap in
    Mathlib — via approximation by finite ranks and continuity — return
    it as well and REPORT; if not, the finite-rank form is the
    contract.) -/
theorem phiLim_finiteDimensional_eq_zero (U : Ultrafilter κ)
    (hcc : PlufWO3.CountablyComplete U)
    (hsmall : PlufWO2.CountableSmall U)
    (M : Submodule ℝ (Hk κ)) (hM : Module.Finite ℝ ↥M) :
    phiLim U hcc M.starProjection = 0 := by
  sorry

/-! ### Part C: countable additivity -/

/-- C1 (Paper III, Theorem 4.1, countable additivity). Let `(q n)` be
    pairwise orthogonal projections onto closed subspaces with
    `phiLim (q n) = 0` for every `n`, and suppose their join `Q` is a
    projection with `⟪Q x, x⟫ = ∑' n, ⟪q n x, x⟫` pointwise (the
    orthogonal-family expansion). Then `phiLim Q = 0`.

    Proof (paper): given `ε > 0`, the sets
    `A n = {α | ⟪q n (evec α), evec α⟫ < ε 2^{-(n+1)}}` lie in `U`, their
    countable intersection lies in `U` by `hcc`, and on it the diagonal
    of `Q` is below `ε`. Hence `phiLim Q ≤ ε` for every `ε`.

    The general statement (dropping `phiLim (q n) = 0`) follows by
    splitting off the at most countably many nonzero values; that
    packaging is C2. -/
theorem phiLim_iSup_eq_zero (U : Ultrafilter κ)
    (hcc : PlufWO3.CountablyComplete U)
    (q : ℕ → Submodule ℝ (Hk κ)) (Q : Submodule ℝ (Hk κ))
    (hq0 : ∀ n, phiLim U hcc (q n).starProjection = 0)
    (hexp : ∀ x : Hk κ, HasSum (fun n => inner (𝕜 := ℝ) ((q n).starProjection x) x)
      (inner (𝕜 := ℝ) (Q.starProjection x) x)) :
    phiLim U hcc Q.starProjection = 0 := by
  sorry

/-- C2 (countable additivity, general form). With the same expansion
    hypothesis, `phiLim Q = ∑' n, phiLim (q n)`. (Split off the nonzero
    terms; finite additivity plus C1. If the tsum bookkeeping proves
    disproportionate, return C1 alone and REPORT — C1 is what Part E and
    the paper's Theorem 4.2 consume.) -/
theorem phiLim_iSup (U : Ultrafilter κ)
    (hcc : PlufWO3.CountablyComplete U)
    (q : ℕ → Submodule ℝ (Hk κ)) (Q : Submodule ℝ (Hk κ))
    (hexp : ∀ x : Hk κ, HasSum (fun n => inner (𝕜 := ℝ) ((q n).starProjection x) x)
      (inner (𝕜 := ℝ) (Q.starProjection x) x)) :
    phiLim U hcc Q.starProjection = ∑' n, phiLim U hcc (q n).starProjection := by
  sorry

/-- C3 (the `<κ`-additive form, generic index). The same argument with an
    arbitrary index type `ι` and the hypothesis that `U` is closed under
    `ι`-indexed intersections, plus: for each `α`, only countably many
    `i` have nonzero diagonal at `α`. This is the generic packaging used
    for κ-completeness throughout this project (cf. WO-3's
    `iInf_mem_PhiU`), and avoids all cardinal arithmetic. -/
theorem phiLim_iSup_eq_zero_generic (U : Ultrafilter κ)
    (hcc : PlufWO3.CountablyComplete U) {ι : Type*}
    (hU : ∀ s : ι → Set κ, (∀ i, s i ∈ U) → (⋂ i, s i) ∈ U)
    (q : ι → Submodule ℝ (Hk κ)) (Q : Submodule ℝ (Hk κ))
    (hq0 : ∀ i, phiLim U hcc (q i).starProjection = 0)
    (hctble : ∀ α : κ, {i | inner (𝕜 := ℝ) ((q i).starProjection (evec α)) (evec α) ≠ 0}.Countable)
    (hexp : ∀ x : Hk κ, ∀ ε > 0, ∃ F : Finset ι,
      inner (𝕜 := ℝ) (Q.starProjection x) x
        ≤ (∑ i ∈ F, inner (𝕜 := ℝ) ((q i).starProjection x) x) + ε) :
    phiLim U hcc Q.starProjection = 0 := by
  sorry

/-! ### Part D: purity, from the face -/

/-- D1. `phiLim` lies in the state face of `Φ(U)`: it takes the value 1
    at every block projection with `S ∈ U` (the diagonal of `P_{block S}`
    is the indicator of `S`), hence at every member by monotonicity. -/
theorem phiLim_mem_face (U : Ultrafilter κ)
    (hcc : PlufWO3.CountablyComplete U) (φ : (Hk κ →L[ℝ] Hk κ) →L[ℝ] ℝ)
    (hφ : PlufWO6.IsState φ) (hval : ∀ T, φ T = phiLim U hcc T)
    (M : Submodule ℝ (Hk κ)) (hM : M ∈ PhiU U) (hMc : IsClosed (M : Set (Hk κ))) :
    φ M.starProjection = 1 := by
  sorry

/-- D2 (purity of φ_U; Paper III, Theorem 4.1, purity clause). Under the
    EPP/paving hypotheses that make `Φ(U)` a pluf (WO-3/WO-4), the face
    of `Φ(U)` is a singleton and `phiLim` is its element; hence `phiLim`
    is a pure state, being an extreme point of the state space by WO-6's
    face machinery.

    Route: WO-6's `rsp_all_iff_face_subsingleton` needs RSP for every
    self-adjoint `T`, which is WO-3's `quadratic_flat` (flattening) at
    `L = phiLim T`. Purity as extremality then follows from the face
    property (`PlufWO6.face_isFace`) applied to the singleton. If
    Mathlib's notion of extreme point is wanted verbatim
    (`Set.extremePoints`), state it that way and REPORT. -/
theorem phiLim_pure (U : Ultrafilter κ)
    (hcc : PlufWO3.CountablyComplete U) (hdiag : PlufWO2.DiagInt U)
    (hsmall : PlufWO2.CountableSmall U)
    (φ ψ : (Hk κ →L[ℝ] Hk κ) →L[ℝ] ℝ)
    (hφ : PlufWO6.IsState φ) (hψ : PlufWO6.IsState ψ)
    (hfφ : ∀ M ∈ PhiU U, ∀ hM : IsClosed (M : Set (Hk κ)), φ M.starProjection = 1)
    (hfψ : ∀ M ∈ PhiU U, ∀ hM : IsClosed (M : Set (Hk κ)), ψ M.starProjection = 1) :
    φ = ψ := by
  sorry

/-! ### Part E: countably additive pure states give plufs -/

section BlecherWeaver

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [CompleteSpace E]

/-- The 1-set of a state, as a family of closed subspaces. -/
def oneSet (φ : (E →L[ℝ] E) →L[ℝ] ℝ) : Set (Submodule ℝ E) :=
  {M | IsClosed (M : Set E) ∧ φ M.starProjection = 1}

/-- The Blecher–Weaver package for a countably additive pure state,
    supplied as named hypotheses (\cite{BlecherWeaver}, §4):
    * `sigma_filter`: the 1-set is closed under countable meets
      (regularity: countable joins of null projections are null);
    * `excision`: every operator admits an excising projection in the
      1-set, `p x p = φ(x) p`.
    Determination of a pure state by its 1-set (their Lemma 4.2) is not
    needed for the contracted conclusions and is omitted; if a face
    clause is wanted, add it as a further hypothesis and REPORT. -/
structure BWPackage (φ : (E →L[ℝ] E) →L[ℝ] ℝ) : Prop where
  sigma_filter : ∀ M : ℕ → Submodule ℝ E, (∀ n, M n ∈ oneSet φ) →
    ∃ N ∈ oneSet φ, ∀ n, N ≤ M n
  excision : ∀ x : E →L[ℝ] E, ∃ M ∈ oneSet φ,
    M.starProjection.comp (x.comp M.starProjection)
      = (φ x) • M.starProjection

/-- E1 (filter clauses). The 1-set of a state satisfying the package is
    upward closed among closed subspaces, closed under binary meets, and
    proper. (Upward: monotonicity of a state, `IsState.mono`. Binary
    meets: the σ-filter clause at a constant-after-two sequence, or
    directly. Properness: `φ 0 = 0 ≠ 1`.) -/
theorem oneSet_upward (φ : (E →L[ℝ] E) →L[ℝ] ℝ) (hφ : PlufWO6.IsState φ)
    (M : Submodule ℝ E) (hM : M ∈ oneSet φ) (N : Submodule ℝ E)
    (hN : IsClosed (N : Set E)) (hMN : M ≤ N) : N ∈ oneSet φ := by
  sorry

theorem oneSet_inf (φ : (E →L[ℝ] E) →L[ℝ] ℝ) (hφ : PlufWO6.IsState φ)
    (hBW : BWPackage φ) (M : Submodule ℝ E) (hM : M ∈ oneSet φ)
    (N : Submodule ℝ E) (hN : N ∈ oneSet φ) : M ⊓ N ∈ oneSet φ := by
  sorry

theorem bot_notMem_oneSet (φ : (E →L[ℝ] E) →L[ℝ] ℝ) (hφ : PlufWO6.IsState φ)
    [Nontrivial E] : (⊥ : Submodule ℝ E) ∉ oneSet φ := by
  sorry

/-- E2 (the excision step; Paper III, Theorem 4.2, maximality). If a
    closed subspace `M` is not in the 1-set, then an excising projection
    for `P_M` gives a member of the 1-set meeting `M` trivially: a unit
    vector `v` in the intersection would satisfy
    `1 = ⟪P_M v, v⟫ = ⟪p P_M p v, v⟫ = φ(P_M) < 1`. -/
theorem exists_oneSet_inf_eq_bot (φ : (E →L[ℝ] E) →L[ℝ] ℝ)
    (hφ : PlufWO6.IsState φ) (hBW : BWPackage φ)
    (M : Submodule ℝ E) (hMc : IsClosed (M : Set E)) (hM : M ∉ oneSet φ) :
    ∃ N ∈ oneSet φ, M ⊓ N = ⊥ := by
  sorry

/-- E3 (Theorem 4.2). The 1-set of a state satisfying the package is a
    pluf, in WO-6's sense `PlufWO6.IsPluf`. (Assemble E1, E2, and WO-6's
    `isPluf_of_criterion`.) -/
theorem isPluf_oneSet (φ : (E →L[ℝ] E) →L[ℝ] ℝ) (hφ : PlufWO6.IsState φ)
    (hBW : BWPackage φ) [Nontrivial E] :
    PlufWO6.IsPluf (oneSet φ) := by
  sorry

/-- E4 (nonprincipality for singular states). If `φ` annihilates every
    finite-dimensional projection, its 1-set contains no line, hence the
    pluf is nonprincipal (WO-6's `principal_of_finiteDimensional`). -/
theorem oneSet_nonprincipal (φ : (E →L[ℝ] E) →L[ℝ] ℝ) (hφ : PlufWO6.IsState φ)
    (hBW : BWPackage φ) [Nontrivial E]
    (hsing : ∀ M : Submodule ℝ E, Module.Finite ℝ ↥M → φ M.starProjection = 0) :
    ∀ v : E, v ≠ 0 → ∃ M ∈ oneSet φ, v ∉ M := by
  sorry

end BlecherWeaver

/-! ### Part F: assembly at κ (Paper I §6 restatement) -/

/-- F1. At a measurable-type ultrafilter, the limit state is a singular,
    countably additive state whose 1-set is exactly `Φ(U)` — the
    statement Paper I's §6 summarizes and Paper III's §4 proves. Contract
    the 1-set identification; the adjectives are Parts B–C.

    (`⊇`: members of `Φ(U)` contain a block of a `U`-set, whose
    projection has diagonal the indicator of that set, so `φ = 1` there
    and monotonicity finishes. `⊆`: if `φ P_M = 1` but `M ∉ Φ(U)`, WO-3's
    `PhiU_decides` gives a member meeting `M` trivially, and E2's
    computation contradicts `φ P_M = 1`.) -/
theorem oneSet_phiLim_eq_PhiU (U : Ultrafilter κ)
    (hcc : PlufWO3.CountablyComplete U) (hdiag : PlufWO2.DiagInt U)
    (hsmall : PlufWO2.CountableSmall U)
    (φ : (Hk κ →L[ℝ] Hk κ) →L[ℝ] ℝ) (hφ : PlufWO6.IsState φ)
    (hval : ∀ T, φ T = phiLim U hcc T) :
    oneSet φ = {M | M ∈ PhiU U ∧ IsClosed (M : Set (Hk κ))} := by
  sorry

/-! ### Axiom audit for the WO-8 contract theorems -/

#print axioms phiLim_spec
#print axioms isState_phiLim
#print axioms phiLim_rankOne_eq_zero
#print axioms phiLim_finiteDimensional_eq_zero
#print axioms phiLim_iSup_eq_zero
#print axioms phiLim_iSup
#print axioms phiLim_iSup_eq_zero_generic
#print axioms phiLim_mem_face
#print axioms phiLim_pure
#print axioms oneSet_upward
#print axioms oneSet_inf
#print axioms bot_notMem_oneSet
#print axioms exists_oneSet_inf_eq_bot
#print axioms isPluf_oneSet
#print axioms oneSet_nonprincipal
#print axioms oneSet_phiLim_eq_PhiU

end PlufWO8
