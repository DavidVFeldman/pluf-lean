/-
  PlufWO2.lean — Work Order 2 for the pluf project (Feldman–Wilce).

  Scope: the measurable-cardinal core of Paper III, in axiom-free form:
    (D) infrastructure — ℓ²(κ) for an arbitrary well-ordered index type,
        countable supports, blocks and coordinate functionals at κ
        (generalizing WO-1's Part B from ℕ; refactor or re-instantiate,
        prover's choice — report which);
    (E) exact paving along an ultrafilter closed under diagonal
        intersections (Paper III, Theorem 2.1);
    (F) the exact dichotomy (Paper III, Theorem 3.1) and the
        maximality-shaped corollary.

  As in WO-1, NO large-cardinal machinery is axiomatized: diagonal
  intersections and smallness-of-countable-sets enter only as hypotheses,
  so every theorem below is a ZFC statement about arbitrary ultrafilters
  on a well-ordered type.

  Ground rules identical to WO-1 (see WORKORDER.md): census first;
  report-rather-than-repair; final artifact sorry/admit/axiom/
  native_decide-free with #print axioms per theorem, whitelist
  propext, Classical.choice, Quot.sound. This WO builds ON TOP of the
  WO-1 artifact (repo DavidVFeldman/pluf-lean, commit 1be8bac): the
  namespace PlufWO1 and its Part A/B lemmas are available and should be
  reused, not duplicated.

  Toolchain: leanprover/lean4:v4.28.0, Mathlib pinned as in the repo.
-/
import RequestProject.PartC

open Set

namespace PlufWO2

variable {κ : Type*} [LinearOrder κ] [WellFoundedLT κ]

/-- The ambient Hilbert space ℓ²(κ; ℝ). -/
abbrev Hk (κ : Type*) : Type _ := lp (fun _ : κ => ℝ) 2

/-- Standard basis vector. -/
noncomputable def evec (α : κ) : Hk κ := lp.single 2 α (1 : ℝ)

/-- Support of a vector of ℓ²(κ). -/
def supp (x : Hk κ) : Set κ := {α | (x : ∀ _ : κ, ℝ) α ≠ 0}

/-- `U` is closed under diagonal intersections (the combinatorial content of
    normality, taken as a hypothesis). -/
def DiagInt (U : Ultrafilter κ) : Prop :=
  ∀ X : κ → Set κ, (∀ α, X α ∈ U) → {β | ∀ α < β, β ∈ X α} ∈ U

/-- Countable sets are `U`-small (the combinatorial content of
    κ-completeness plus nonprincipality, for the uses below). -/
def CountableSmall (U : Ultrafilter κ) : Prop :=
  ∀ s : Set κ, s.Countable → sᶜ ∈ U

/-! ### Part D: infrastructure at κ -/

/-- D1. Every vector of ℓ²(κ) has countable support (Paper III uses this
    silently throughout; it is the entire reason the subject softens at κ).
    Route: `Memℓp` gives summability of the squared coordinates; summable
    families over ℝ have countable support. -/
theorem countable_supp (x : Hk κ) : (supp x).Countable := by
  sorry

/-- D2. Coordinate evaluation as a continuous linear functional on ℓ²(κ)
    (the κ-generalization of WO-1's `coordCLM`; if the WO-1 definition is
    refactored to an arbitrary index type, this item is that refactor). -/
noncomputable def coordCLM (α : κ) : Hk κ →L[ℝ] ℝ := sorry

@[simp] theorem coordCLM_apply (α : κ) (x : Hk κ) :
    coordCLM α x = (x : ∀ _ : κ, ℝ) α := by
  sorry

/-- D3. The block of a set `S ⊆ κ`: the closed subspace of vectors
    supported in `S`, with the membership characterization and closedness
    (κ-generalization of WO-1's `block`, `mem_block_iff`, `isClosed_block`). -/
noncomputable def block (S : Set κ) : Submodule ℝ (Hk κ) := sorry

theorem mem_block_iff (S : Set κ) (x : Hk κ) :
    x ∈ block S ↔ ∀ α ∉ S, (x : ∀ _ : κ, ℝ) α = 0 := by
  sorry

theorem isClosed_block (S : Set κ) : IsClosed (block S : Set (Hk κ)) := by
  sorry

/-- D4. Blocks of basis vectors: `evec α ∈ block S ↔ α ∈ S`, and the block
    of `S` contains `evec α` for `α ∈ S`. (Small glue, stated for reuse.) -/
theorem evec_mem_block {S : Set κ} {α : κ} (hα : α ∈ S) : evec α ∈ block S := by
  sorry

/-! ### Part E: exact paving -/

/-- E1 (Exact paving; Paper III, Theorem 2.1). Along an ultrafilter closed
    under diagonal intersections and concentrating off countable sets, every
    bounded operator compresses to an exactly diagonal operator on a
    measure-one block: there is `S ∈ U` such that all off-diagonal matrix
    entries over `S` vanish.

    Proof sketch (paper): for each `α` the set
    `c α = supp (T (evec α)) ∪ supp (T.adjoint (evec α))` is countable (D1),
    so `(c α)ᶜ ∈ U`; the diagonal intersection `S` of these complements lies
    in `U`, and for `α < β` in `S`, membership `β ∈ (c α)ᶜ` kills
    `⟪T (evec α), evec β⟫` directly and `⟪T (evec β), evec α⟫` through the
    adjoint. -/
theorem exact_paving (U : Ultrafilter κ) (hdiag : DiagInt U)
    (hsmall : CountableSmall U) (T : Hk κ →L[ℝ] Hk κ) :
    ∃ S ∈ U, ∀ α ∈ S, ∀ β ∈ S, α ≠ β →
      inner (𝕜 := ℝ) (T (evec α)) (evec β) = 0 := by
  sorry

/-! ### Part F: the exact dichotomy -/

/-- F1 (orthogonality of the defect vectors). Applying E1 to the orthogonal
    projection onto `Wᗮ` (which exists: `Wᗮ` is closed, hence complete)
    yields `S₀ ∈ U` on which the vectors `g α = P_{Wᗮ} (evec α)` are
    pairwise orthogonal. State in whatever packaging serves F2; the contract
    is F2 itself, and this item may be inlined. -/

/-- F2 (Exact dichotomy; Paper III, Theorem 3.1). For every closed subspace
    `W` of ℓ²(κ) there is `S ∈ U` with `block S ≤ W` or `W ⊓ block S = ⊥`.

    Proof sketch (paper): with `S₀` and `g α` as in F1, for
    `x = ∑ c α • evec α ∈ block S₀` one has
    `‖P_{Wᗮ} x‖² = ∑ |c α|² ‖g α‖²` with no cross terms, so
    `W ⊓ block S₀ = block S₁` EXACTLY, where
    `S₁ = {α ∈ S₀ | evec α ∈ W}`. The ultrafilter decides `S₁` or
    `S₀ \ S₁`.

    Convergence note for the prover: the identity
    `P_{Wᗮ} x = ∑ c α • g α` needs only continuity of `P_{Wᗮ}` and the
    ℓ²-expansion of `x` over `S₀`; the cross-term vanishing then reduces the
    norm computation to a `tsum` of squares, or — likely lighter — one can
    avoid norms entirely and argue coordinate-by-coordinate in the style of
    WO-1's C1 coordinate-rigidity functional. Prover's choice; report the
    route taken. -/
theorem exact_dichotomy (U : Ultrafilter κ) (hdiag : DiagInt U)
    (hsmall : CountableSmall U) (W : Submodule ℝ (Hk κ))
    (hW : IsClosed (W : Set (Hk κ))) :
    ∃ S ∈ U, block S ≤ W ∨ W ⊓ block S = ⊥ := by
  sorry

/-- F3 (maximality-shaped corollary; Paper III, Corollary 3.2, lattice
    half). Every closed subspace is decided by the block family of `U`:
    either it contains a measure-one block, or a measure-one block meets it
    trivially. This is F2 restated with the block filter's membership
    predicate made explicit; it is what \cite{FWI}, Lemma 2.1 consumes to
    conclude that the block filter is a pluf. -/
theorem block_filter_decides (U : Ultrafilter κ) (hdiag : DiagInt U)
    (hsmall : CountableSmall U) (W : Submodule ℝ (Hk κ))
    (hW : IsClosed (W : Set (Hk κ))) :
    (∃ S ∈ U, block S ≤ W) ∨ (∃ S ∈ U, W ⊓ block S = ⊥) := by
  sorry

end PlufWO2
