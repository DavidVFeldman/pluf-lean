/-
  PlufWO3.lean — Work Order 3 for the pluf project (Feldman–Wilce).

  Scope: the remaining lattice-level assertions of Paper III:
    (G) ultrafilter limits of bounded functions along countably complete
        ultrafilters, and the diagonal-flattening corollary
        (Paper III, Corollary 2.2, quadratic-form formulation);
    (H) the block filter Φ(U) as a filter: properness, upward closure,
        closure under (arbitrary-index) intersections, nonprincipality,
        and the decision property (Paper III, Corollary 3.2, filter half);
    (I) the κ-witness subspace of a partition into countable pieces and
        the non-maximality proposition (Paper III, Proposition 5.3,
        Hilbert half).

  As in WO-1/WO-2, NO large-cardinal machinery is axiomatized:
  `DiagInt`, `CountableSmall`, `CountablyComplete`, and generic
  intersection-closure enter only as hypotheses.

  This WO builds on the WO-2 artifact (repo `pluf-lean`, both prior audits
  green): namespaces `PlufWO1` and `PlufWO2` are available and MUST be
  reused — in particular `PlufWO2.block`, `PlufWO2.evec`,
  `PlufWO2.hasSum_evec_smul`, `PlufWO2.hasSum_coord_smul`,
  `PlufWO2.inner_eq_coord_mul`, `PlufWO2.block_le_of_evec_mem`,
  `PlufWO2.exact_paving`, `PlufWO2.block_filter_decides`, and
  `PlufWO1.IsPartialSelector`. Do not duplicate them.

  Ground rules identical to WO-1/WO-2 (census first; report-rather-than-
  repair; no sorry/admit/axiom/native_decide; #print axioms per contract
  theorem, whitelist propext, Classical.choice, Quot.sound; WO-1's and
  WO-2's 24 theorems must remain green).

  Toolchain: leanprover/lean4:v4.28.0, Mathlib pinned as in the repo.
-/
import RequestProject.PlufWO2

open Set PlufWO2

namespace PlufWO3

variable {κ : Type*} [LinearOrder κ]

/-- `U` is countably complete. -/
def CountablyComplete (U : Ultrafilter κ) : Prop :=
  ∀ s : ℕ → Set κ, (∀ n, s n ∈ U) → (⋂ n, s n) ∈ U

/-! ### Part G: ultrafilter limits and diagonal flattening -/

omit [LinearOrder κ] in
/-- G1. A bounded real-valued function has a limit along a countably
    complete ultrafilter. (Bisection: the U-decided halves of a nested
    interval sequence intersect by countable completeness; the limit is the
    common point. Uniqueness is immediate and need not be stated.) -/
theorem exists_ulim (U : Ultrafilter κ) (hcc : CountablyComplete U)
    (f : κ → ℝ) (C : ℝ) (hbd : ∀ α, |f α| ≤ C) :
    ∃ L : ℝ, ∀ ε > 0, {α | |f α - L| ≤ ε} ∈ U := by
  sorry

/-- G2 (Diagonal flattening; Paper III, Corollary 2.2, quadratic-form
    formulation). If the diagonal entries of `T` have `U`-limit `L`, then
    for every `ε > 0` there is `S ∈ U` on which the quadratic form of `T`
    is within `ε` of `L` times the norm-squared, uniformly on the block.

    Proof sketch: shrink the exact-paving set (E1) inside the `hL` set for
    `ε`; for `x ∈ block S`, expand `⟪T x, x⟫ = ∑' β, x β * ⟪T (evec β), x⟫`
    (push `hasSum_evec_smul` through `T` and then through `⟪·, x⟫` — over ℝ
    the inner product is bilinear), and apply `inner_eq_coord_mul` with
    `P := T` on the diagonalizing block to reduce each term to
    `(x β)^2 * d β` with `d β ∈ [L−ε, L+ε]` for `β ∈ S` and `x β = 0` off
    `S`; conclude by comparison with `∑' β, (x β)^2 = ‖x‖²`
    (`lp.inner_eq_tsum` plus `real_inner_self_eq_norm_sq`, or the `HasSum`
    form — prover's choice). Note no self-adjointness is required: exact
    paving already used the adjoint internally, and the expansion is
    orientation-uniform. -/
theorem quadratic_flat (U : Ultrafilter κ) (hdiag : DiagInt U)
    (hsmall : CountableSmall U) (T : Hk κ →L[ℝ] Hk κ) (L : ℝ)
    (hL : ∀ ε > 0, {α | |inner (𝕜 := ℝ) (T (evec α)) (evec α) - L| ≤ ε} ∈ U)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ S ∈ U, ∀ x ∈ block S,
      |inner (𝕜 := ℝ) (T x) x - L * ‖x‖ ^ 2| ≤ ε * ‖x‖ ^ 2 := by
  sorry

/-! ### Part H: the block filter Φ(U), as a filter -/

/-- The block filter: closed subspaces containing a measure-one block.
    (Membership is deliberately stated for arbitrary submodules; the
    lattice-theoretic assertions below do not need closedness of the
    members, only of the subspaces being decided.) -/
def PhiU (U : Ultrafilter κ) : Set (Submodule ℝ (Hk κ)) :=
  {M | ∃ S ∈ U, block S ≤ M}

omit [LinearOrder κ] in
/-- H1 (filter axioms). Φ(U) is upward closed, closed under pairwise
    intersection, and proper (⊥ is not a member). Properness uses only
    that members of an ultrafilter are nonempty. -/
theorem PhiU_upward (U : Ultrafilter κ) {M N : Submodule ℝ (Hk κ)}
    (hM : M ∈ PhiU U) (hMN : M ≤ N) : N ∈ PhiU U := by
  sorry

omit [LinearOrder κ] in
theorem inf_mem_PhiU (U : Ultrafilter κ) {M N : Submodule ℝ (Hk κ)}
    (hM : M ∈ PhiU U) (hN : N ∈ PhiU U) : M ⊓ N ∈ PhiU U := by
  sorry

omit [LinearOrder κ] in
theorem bot_notMem_PhiU (U : Ultrafilter κ) : ⊥ ∉ PhiU U := by
  sorry

omit [LinearOrder κ] in
/-- H2 (completeness, generic form). If `U` is closed under `ι`-indexed
    intersections, then so is Φ(U) under `ι`-indexed infima. Instantiating
    `ι := ℕ` with `CountablyComplete` gives σ-completeness; at a measurable
    cardinal the hypothesis holds for every `ι` of size `< κ`, giving the
    κ-completeness of Paper III, Corollary 3.2 — but no cardinal arithmetic
    appears here. -/
theorem iInf_mem_PhiU (U : Ultrafilter κ) {ι : Type*}
    (hU : ∀ s : ι → Set κ, (∀ i, s i ∈ U) → (⋂ i, s i) ∈ U)
    (M : ι → Submodule ℝ (Hk κ)) (hM : ∀ i, M i ∈ PhiU U) :
    (⨅ i, M i) ∈ PhiU U := by
  sorry

omit [LinearOrder κ] in
/-- H3 (nonprincipality). A vector lying in every member of Φ(U) is zero:
    its support is countable (D1), so the block of the complement is a
    member that excludes it unless every coordinate vanishes. -/
theorem PhiU_nonprincipal (U : Ultrafilter κ) (hsmall : CountableSmall U)
    (x : Hk κ) (hx : ∀ M ∈ PhiU U, x ∈ M) : x = 0 := by
  sorry

/-- H4 (the decision property, membership form; Paper III, Corollary 3.2,
    filter half). Every closed subspace is a member of Φ(U) or is met
    trivially by a member. With H1–H3 this is the assertion that Φ(U) is a
    nonprincipal maximal filter of closed subspaces, via the maximality
    criterion of the companion paper. -/
theorem PhiU_decides (U : Ultrafilter κ) (hdiag : DiagInt U)
    (hsmall : CountableSmall U) (W : Submodule ℝ (Hk κ))
    (hW : IsClosed (W : Set (Hk κ))) :
    W ∈ PhiU U ∨ ∃ M ∈ PhiU U, W ⊓ M = ⊥ := by
  sorry

/-! ### Part I: the κ-witness (Paper III, Proposition 5.3, Hilbert half) -/

section Witness

variable {ι : Type*} (P : ι → Set κ)

/-- I1a. The constraint vector of a countable set: coordinates
    `2^{-(g(α)+1)}` on `P₀` for an injection `g : P₀ ↪ ℕ` furnished by
    countability, zero off `P₀`. The choice of injection is internal; the
    contract is the specification lemmas I1b–I1d. -/
noncomputable def kConstraintVec (P₀ : Set κ) (hP : P₀.Countable) : Hk κ :=
  sorry

omit [LinearOrder κ] in
/-- I1b. Membership specification: the support is exactly `P₀`. -/
theorem supp_kConstraintVec (P₀ : Set κ) (hP : P₀.Countable) :
    supp (kConstraintVec P₀ hP) = P₀ := by
  sorry

omit [LinearOrder κ] in
/-- I1c. Coordinates are nonnegative (used only to keep the two-point
    witness computation explicit; if a cleaner normalization serves,
    restate and report). -/
theorem kConstraintVec_nonneg (P₀ : Set κ) (hP : P₀.Countable) (α : κ) :
    0 ≤ (kConstraintVec P₀ hP : ∀ _ : κ, ℝ) α := by
  sorry

/-- The κ-witness subspace of a family of countable pieces. -/
noncomputable def Wk (h : ∀ i, (P i).Countable) : Submodule ℝ (Hk κ) :=
  ⨅ i, LinearMap.ker
    ((innerSL ℝ (kConstraintVec (P i) (h i)) : Hk κ →L[ℝ] ℝ) : Hk κ →ₗ[ℝ] ℝ)

omit [LinearOrder κ] in
/-- I1d. Membership characterization and closedness of `Wk`. -/
theorem mem_Wk_iff (h : ∀ i, (P i).Countable) (x : Hk κ) :
    x ∈ Wk P h ↔ ∀ i, inner (𝕜 := ℝ) x (kConstraintVec (P i) (h i)) = 0 := by
  sorry

omit [LinearOrder κ] in
theorem isClosed_Wk (h : ∀ i, (P i).Countable) :
    IsClosed (Wk P h : Set (Hk κ)) := by
  sorry

omit [LinearOrder κ] in
/-- I2 (unadded). If the pieces cover κ, then no nonempty block sits inside
    `Wk`: a point `α` of `S` lies in some piece, and `evec α` pairs
    nontrivially with that piece's constraint vector. Consequently
    `Wk ∉ Φ(U)` for any (proper) ultrafilter. -/
theorem not_block_le_Wk (h : ∀ i, (P i).Countable)
    (hcover : (⋃ i, P i) = univ) {S : Set κ} (hS : S.Nonempty) :
    ¬ block S ≤ Wk P h := by
  sorry

omit [LinearOrder κ] in
theorem Wk_notMem_PhiU (U : Ultrafilter κ) (h : ∀ i, (P i).Countable)
    (hcover : (⋃ i, P i) = univ) : Wk P h ∉ PhiU U := by
  sorry

omit [LinearOrder κ] in
/-- I3 (blocking characterized). For pairwise disjoint pieces, a block
    meets `Wk` trivially exactly when its index set is a partial selector.

    (⇐) On a selector, each piece contributes at most one coordinate, and
    the single surviving term of each constraint kills it.
    (⇒) Two points of `S` in one piece give the explicit two-point witness
    `c_β • evec α − c_α • evec β` (coefficients read off the constraint
    vector), orthogonal to that piece's constraint by construction and to
    every other constraint by disjoint supports — WO-1's C2 move at κ. -/
theorem Wk_inf_block_eq_bot_iff (h : ∀ i, (P i).Countable)
    (hdisj : Pairwise (Function.onFun Disjoint P))
    (hne : ∀ i, (P i).Nonempty) (S : Set κ) :
    Wk P h ⊓ block S = ⊥ ↔ PlufWO1.IsPartialSelector S P := by
  sorry

omit [LinearOrder κ] in
/-- I4 (the κ-witness; Paper III, Proposition 5.3, Hilbert half). If no
    set of `U` is a partial selector of a partition of κ into countable
    nonempty pieces, then the witness subspace is unadded yet meets every
    member of Φ(U) nontrivially — the negation, via the maximality
    criterion, of maximality of the block filter. -/
theorem kappa_witness (U : Ultrafilter κ) (h : ∀ i, (P i).Countable)
    (hdisj : Pairwise (Function.onFun Disjoint P))
    (hne : ∀ i, (P i).Nonempty) (hcover : (⋃ i, P i) = univ)
    (hsel : ∀ S ∈ U, ¬ PlufWO1.IsPartialSelector S P) :
    Wk P h ∉ PhiU U ∧ ∀ M ∈ PhiU U, Wk P h ⊓ M ≠ ⊥ := by
  sorry

end Witness

/-! ### Axiom audit for the WO-3 contract theorems
(The WO-1 and WO-2 audits run via the import chain.) -/

#print axioms exists_ulim              -- G1
#print axioms quadratic_flat           -- G2
#print axioms PhiU_upward              -- H1
#print axioms inf_mem_PhiU             -- H1
#print axioms bot_notMem_PhiU          -- H1
#print axioms iInf_mem_PhiU            -- H2
#print axioms PhiU_nonprincipal        -- H3
#print axioms PhiU_decides             -- H4
#print axioms supp_kConstraintVec      -- I1
#print axioms mem_Wk_iff               -- I1
#print axioms isClosed_Wk              -- I1
#print axioms Wk_notMem_PhiU           -- I2
#print axioms Wk_inf_block_eq_bot_iff  -- I3
#print axioms kappa_witness            -- I4

end PlufWO3
