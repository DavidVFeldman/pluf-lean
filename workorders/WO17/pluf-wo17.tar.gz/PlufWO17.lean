/-
  PlufWO17.lean — Work Order 17 for the pluf project (Feldman, Wilce).

  Scope: the remainder of Paper V — Sections 4, 5 and 6 — completing its
  verification:
    (A) the scrawl vocabulary, defined here rather than imported, and
        Theorem 4.3: the support family satisfies (S1) outright and (S2) for
        finite deleted sets;
    (B) Theorem 5.2: the finite-rank classification, with the theorem of
        Aroca et al. quarantined as a named hypothesis;
    (C) Lemma 6.1 (zeros of an exponential sum), Example 6.2 (the model
        space realizes every cofinite set), and the conditional consequence
        of Section 6.

  ON VOCABULARY. The WO-16 census reported that Mathlib's `Matroid` supports
  infinite ground sets, circuits, elimination and duality, but offers no
  constructor building a matroid from a circuit family, and no scrawls,
  cofinitary duals or representability. This work order does NOT wait on that.
  Everything Paper V asserts is a statement about families of subsets of ℕ and
  about kernels of matrices, and Part A defines the three predicates it needs
  from scratch — `IsCircuitFamily`, `IsScrawlFamily`, and the maximality axiom
  — in a dozen lines. Do not import `Mathlib.Data.Matroid`; do not attempt to
  build a `Matroid` instance. If a later Mathlib gains the constructor, the
  bridge is one lemma and is not this commission's business.

  ON THE MODEL SPACE. Paper V's Example 6.2 has been rewritten since the WO-16
  census: the generalized Vandermonde determinant and Cramer's rule are gone,
  replaced by a dimension count against Lemma 6.1. That census reported
  Vandermonde positivity absent from Mathlib and recommended leaving Section 6
  alone; the rewrite removes the dependency, and Part C is contracted against
  the new proof. The only analytic input is Rolle's theorem.

  Base: the tree after WO-16 (261 theorems; CI runs #1–#15).
  `PlufWO17.lean` imports `RequestProject.PlufWO16`. All 261 prior theorems
  must remain green; `PlufWO7a.lean` is the census record and is not to be
  edited.

  Scalars: over ℝ, as in WO-16, and for the same reason.

  Toolchain: leanprover/lean4:v4.28.0, Mathlib pinned as in the repo.
-/
import RequestProject.PlufWO16

open Set

namespace PlufWO17

abbrev H := PlufWO1.H
open PlufWO16 (supp)

/-! ### Part A: scrawls, and the two axioms the support family satisfies -/

/-- A family of subsets of `ι` is a *circuit family* if it is a nonempty
    antichain of nonempty sets satisfying circuit elimination. -/
structure IsCircuitFamily {ι : Type*} (C : Set (Set ι)) : Prop where
  nonempty : C.Nonempty
  ne_empty : ∀ c ∈ C, c.Nonempty
  antichain : ∀ c ∈ C, ∀ c' ∈ C, c ⊆ c' → c = c'
  elimination : ∀ c ∈ C, ∀ c' ∈ C, c ≠ c' → ∀ p ∈ c ∩ c',
    ∃ c'' ∈ C, c'' ⊆ (c ∪ c') \ {p}

/-- The sets containing no member of `C`. -/
def IndepOf {ι : Type*} (C : Set (Set ι)) : Set (Set ι) :=
  {S | ∀ c ∈ C, ¬ c ⊆ S}

/-- The maximality axiom (SM) of Bruhn–Diestel–Kriesell–Pendavingh–Wollan. -/
def HasSM {ι : Type*} (C : Set (Set ι)) : Prop :=
  ∀ X : Set ι, ∀ I ∈ IndepOf C, I ⊆ X →
    ∃ J ∈ IndepOf C, I ⊆ J ∧ J ⊆ X ∧ ∀ K ∈ IndepOf C, J ⊆ K → K ⊆ X → K = J

/-- `F` is the scrawl family of a matroid: the unions of members of some
    circuit family satisfying (SM), together with the empty set. -/
def IsScrawlFamily {ι : Type*} (F : Set (Set ι)) : Prop :=
  ∃ C, IsCircuitFamily C ∧ HasSM C ∧
    F = {S | ∃ D ⊆ C, S = ⋃ c ∈ D, c}

/-- The support family of a submodule. -/
def suppFamily (M : Submodule ℝ H) : Set (Set ℕ) := {S | ∃ x ∈ M, supp x = S}

/-- A1 (Paper V, Theorem 4.3, axiom (S1)). The support family of a closed
    submodule is closed under arbitrary unions. This is WO-16's
    `exists_supp_sUnion` restated in the vocabulary above; cite rather than
    reprove. -/
theorem suppFamily_sUnion_closed (M : Submodule ℝ H) (hM : IsClosed (M : Set H))
    (G : Set (Set ℕ)) (hG : G ⊆ suppFamily M) :
    (⋃ S ∈ G, S) ∈ suppFamily M := by
  sorry

/-- A2 (Paper V, Theorem 4.3, axiom (S2) for finite deleted sets). Let
    `w = supp x` with `x ∈ M`, let `X ⊆ w` be finite, and for `p ∈ X` let
    `u p ∈ M` have support `w p` with `p ∈ w q ↔ p = q`. Then for every
    `z ∈ w \ ⋃ p, w p` some `y ∈ M` has
    `z ∈ supp y ⊆ (w ∪ ⋃ p, w p) \ X`.

    (The correction `y = x - ∑_{p ∈ X} (x p / u p p) • u p` is a finite sum,
    hence in `M`; it kills each `p ∈ X` and does not touch `z`.) -/
theorem suppFamily_elimination_finite (M : Submodule ℝ H) (x : H) (hx : x ∈ M)
    (X : Finset ℕ) (hXw : ↑X ⊆ supp x) (u : ℕ → H) (hu : ∀ p ∈ X, u p ∈ M)
    (hsupp : ∀ p ∈ X, ∀ q ∈ X, p ∈ supp (u q) ↔ p = q)
    {z : ℕ} (hz : z ∈ supp x) (hznot : ∀ p ∈ X, z ∉ supp (u p)) :
    ∃ y ∈ M, z ∈ supp y ∧
      supp y ⊆ (supp x ∪ ⋃ p ∈ X, supp (u p)) \ ↑X := by
  sorry

/-! ### Part B: the finite-rank classification -/

/-- The Aroca–Bossinger–Falkensteiner–Garay López–González-Ramírez–Valencia
    Negrete theorem, quarantined as a hypothesis exactly as Mathias, MSS and
    Blecher–Weaver are elsewhere in this development. For a nonzero
    finite-dimensional `W ⊆ (ι → ℝ)` with `ι` countable, the supports of
    members of `W` form the scrawl family of a circuit family, namely the
    minimal nonempty supports.

    State it about `T(W)` as the source does, NOT about the support family of a
    closed subspace of `ℓ²`; the transfer between the two is the content of B2
    and B3 and must not be smuggled into the hypothesis. -/
def AroKaHyp : Prop :=
  ∀ (W : Submodule ℝ (ℕ → ℝ)), W ≠ ⊥ → Module.Finite ℝ ↥W →
    IsScrawlFamily {S : Set ℕ | ∃ f ∈ W, {n | f n ≠ 0} = S}

/-- B1 (coordinates see the same supports). The image of a finite-rank closed
    submodule of `ℓ²` under the inclusion into `ℕ → ℝ` has the same support
    family. -/
theorem suppFamily_eq_coords (M : Submodule ℝ H) :
    suppFamily M
      = {S : Set ℕ | ∃ f ∈ M.map (PlufWO16.toFun), {n | f n ≠ 0} = S} := by
  sorry

/-- B2 (support-preserving realization; the item the WO-16 census identified as
    carrying the content). Every finite-dimensional subspace `W` of `ℕ → ℝ` is
    carried, by a diagonal rescaling with nonvanishing entries, onto a
    finite-dimensional — hence closed — subspace of `ℓ²` with the same support
    family.

    (Pick a basis `f₁, …, f_d` of `W`; choose weights `c n > 0` small enough
    that each `c • f i` is square-summable, e.g.
    `c n = 2^{-n} / (1 + max_i |f i n|)`; multiplication by a nonvanishing
    sequence preserves supports.) -/
theorem exists_realization_in_lp (W : Submodule ℝ (ℕ → ℝ))
    (hW : Module.Finite ℝ ↥W) :
    ∃ M : Submodule ℝ H, Module.Finite ℝ ↥M ∧
      suppFamily M = {S : Set ℕ | ∃ f ∈ W, {n | f n ≠ 0} = S} := by
  sorry

/-- B3 (Paper V, Theorem 5.2). Under the quarantined hypothesis, the support
    family of a nonzero finite-rank closed submodule of `ℓ²` is a scrawl
    family, and conversely every scrawl family of the form given by a
    finite-dimensional `W ⊆ ℕ → ℝ` is realized by such a submodule.

    Assemble B1, B2 and `AroKaHyp`. Report whether the finite-dimensionality of
    a subspace of `ℓ²` is enough for closedness in the form Mathlib supplies
    (`Submodule.closed_of_finiteDimensional` or kin). -/
theorem suppFamily_isScrawlFamily (h : AroKaHyp)
    (M : Submodule ℝ H) (hM : M ≠ ⊥) (hfin : Module.Finite ℝ ↥M) :
    IsScrawlFamily (suppFamily M) := by
  sorry

/-! ### Part C: the model space -/

/-- C1 (Paper V, Lemma 6.1). An exponential sum with `m` distinct exponents and
    a nonzero coefficient vector has at most `m - 1` real zeros.

    Proof: induct on `m`, discarding vanishing coefficients. For `m > 1`,
    `m` zeros of `F` are `m` zeros of `G t = exp (-μ₁ * t) * F t`, so Rolle
    gives `m - 1` zeros of `G'`, which is an exponential sum with `m - 1`
    nonzero coefficients and distinct exponents.

    State the conclusion in whichever form the induction supports —
    `Set.Finite` with a cardinality bound, or "no `m` distinct zeros" — and
    REPORT the choice; C2 consumes only the second. Rolle is
    `exists_deriv_eq_zero` / `exists_hasDerivAt_eq_zero` in Mathlib. -/
theorem expSum_zeros_lt (m : ℕ) (μ : Fin m → ℝ) (hμ : Function.Injective μ)
    (a : Fin m → ℝ) (ha : a ≠ 0) (t : Fin m → ℝ) (ht : Function.Injective t)
    (hz : ∀ i, ∑ k, a k * Real.exp (μ k * t i) = 0) :
    False := by
  sorry

/-- The geometric vectors of the example. -/
noncomputable def geom (lam : ℝ) : H := sorry

theorem geom_apply {lam : ℝ} (h0 : 0 < lam) (h1 : lam < 1) (n : ℕ) :
    (geom lam : ∀ _ : ℕ, ℝ) n = lam ^ n := by
  sorry

/-- C2 (Paper V, Example 6.2). For distinct `λ₁, …` in `(0,1)`, the closed span
    of the `geom (λ k)` realizes every cofinite subset of `ℕ` as a support.

    Proof (paper, rewritten): put `m = |S| + 1`. By C1 with `μ k = log (λ k)`,
    a nontrivial combination of `geom (λ 1), …, geom (λ m)` vanishes at no more
    than `m - 1` points of `ℕ`; in particular those vectors are independent, so
    their span has dimension `m`. Evaluation at the `m - 1` points of `S` is a
    linear map to `ℝ^(m-1)`, so some nonzero `x` in the span vanishes on `S`;
    having at least and at most `m - 1` zeros, its zero set is exactly `S`. -/
theorem exists_supp_compl_finite (lam : ℕ → ℝ)
    (hpos : ∀ k, 0 < lam k) (hlt : ∀ k, lam k < 1) (hinj : Function.Injective lam)
    (S : Finset ℕ) :
    ∃ x ∈ (Submodule.span ℝ (Set.range fun k => geom (lam k))).topologicalClosure,
      supp x = (↑S : Set ℕ)ᶜ := by
  sorry

/-- C3 (Paper V, Section 6, the conditional). Suppose the closed span above has
    no nonzero vector with infinitely many vanishing coordinates. Then its
    support family is `{∅} ∪ {cofinite sets}`; it has no minimal nonempty
    member; the sets containing no nonempty support are exactly the coinfinite
    sets, and among the subsets of `ℕ` these have no maximal element, so the
    conclusion of (SM) fails for the family. In particular the support family
    is the scrawl family of no circuit family.

    Deliver the last clause as the negation of `IsScrawlFamily`; the chain
    above is the argument. The hypothesis is Paper V's Question 9.3 and is
    supplied here, not proved. -/
theorem not_isScrawlFamily_of_cofiniteOnly (M : Submodule ℝ H)
    (hM : IsClosed (M : Set H))
    (hcof : ∀ x ∈ M, x ≠ 0 → (supp x)ᶜ.Finite)
    (hall : ∀ S : Finset ℕ, ∃ x ∈ M, supp x = (↑S : Set ℕ)ᶜ) :
    ¬ IsScrawlFamily (suppFamily M) := by
  sorry

/-! ### Axiom audit -/

#print axioms suppFamily_sUnion_closed
#print axioms suppFamily_elimination_finite
#print axioms suppFamily_eq_coords
#print axioms exists_realization_in_lp
#print axioms suppFamily_isScrawlFamily
#print axioms expSum_zeros_lt
#print axioms geom_apply
#print axioms exists_supp_compl_finite
#print axioms not_isScrawlFamily_of_cofiniteOnly

end PlufWO17
