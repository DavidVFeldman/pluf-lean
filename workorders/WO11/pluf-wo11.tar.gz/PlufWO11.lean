/-
  PlufWO11.lean — Work Order 11 for the pluf project (Feldman–Wilce).

  Scope: the cardinal infrastructure shared by the two remaining
  transfinite commissions (WO-12, Paper II Theorem 5.4; WO-15, Paper I
  Theorem 5.7 and Proposition 5.9). Paid once here, consumed twice:
    (A) the three cardinality computations: the closed subspaces of H, the
        ℕ-indexed orthonormal bases of H, and the bounded operators on H,
        each of cardinality 𝔠;
    (B) the CH enumerations: under CH as a hypothesis, each of those three
        sets is enumerated by the countable ordinals, in the shape WO-9's
        recursion combinator consumes;
    (C) the bookkeeping lemmas the recursions need at each stage: proper
        initial segments of ω₁ are countable, and the countable-union
        closure that keeps a stage's accumulated data countable.

  NOTHING HERE IS ANALYSIS. If an item starts to require Hilbert-space
  argument beyond the separability of H and the existence of its standard
  basis, that is a sign the contract is wrong — REPORT it.

  CH is a hypothesis (`Cardinal.continuum = Cardinal.aleph 1`), never an
  axiom, and appears only in Part B. Part A and Part C are ZFC.

  A NOTE ON GENERALITY. Every statement below is contracted concretely at
  `PlufWO1.H`, the standard separable infinite-dimensional real Hilbert
  space of this project, rather than at an abstract space. This is
  deliberate: the last two commissions each caught a false contract of the
  form "every separable complete space admits an ℕ-indexed Hilbert basis"
  (`E = ℝ` refutes it). If a general form is wanted, it needs
  `¬ FiniteDimensional` and separability, and its statement should be
  derived from the concrete one rather than replacing it. Generalize only
  if cheap, and REPORT.

  Base: the WO-10 artifact (181 theorems; CI runs #1–#10). All prior
  theorems must remain green; `PlufWO7a.lean` remains the census record.

  Toolchain: leanprover/lean4:v4.28.0, Mathlib pinned as in the repo.
-/
import RequestProject.PlufWO10

open Set Cardinal

namespace PlufWO11

/-- Abbreviation for the working space. -/
abbrev H := PlufWO1.H

/-! ### Part A: the three cardinality computations -/

/-- A1. The closed subspaces of `H` number exactly the continuum.

    Upper bound: a closed subspace is determined by any countable dense
    subset of it (`H` is separable, so every subspace is separable), so the
    assignment into countable sequences from `H` is injective, giving
    `𝔠 ^ ℵ₀ = 𝔠`. Lower bound: the lines `ℝ ∙ v` for `v` on the unit
    sphere are pairwise distinct up to sign, and the sphere has cardinality
    `𝔠`; a cleaner lower bound, if preferred, is the blocks `block S` for
    `S ⊆ ℕ`, which are pairwise distinct — that route needs only
    `PlufWO1.mem_block_iff` and is probably shortest. Prover's choice,
    reported. -/
theorem mk_closedSubspaces :
    #{M : Submodule ℝ H // IsClosed (M : Set H)} = continuum := by
  sorry

/-- A2. The ℕ-indexed orthonormal bases of `H` number exactly the
    continuum.

    Upper bound: a `HilbertBasis ℕ ℝ H` is determined by the underlying
    function `ℕ → H`, so `𝔠 ^ ℵ₀ = 𝔠`. Lower bound: rotating the first two
    standard basis vectors by an angle `θ` gives pairwise distinct bases,
    one for each `θ` in an interval — the rotation may be defined by hand
    on the two-dimensional coordinate span and extended by the identity;
    the distinctness is visible in the zeroth vector. If Mathlib's
    `HilbertBasis` bundling makes the family construction awkward, an
    alternative lower bound is to reindex the standard basis along the
    permutations of ℕ that swap finitely... (no: those are only countably
    many). Use the rotations, or any other family of size `𝔠`, and report
    what was used. -/
theorem mk_hilbertBases : #(HilbertBasis ℕ ℝ H) = continuum := by
  sorry

/-- A3. The bounded operators on `H` number exactly the continuum, and so
    do the self-adjoint ones. (Upper bound: continuity plus separability
    make an operator determined by its values on a countable dense set.
    Lower bound: the scalar multiples of the identity, or the diagonal
    operators with entries in `{0,1}` — the latter give `𝔠` directly and
    are self-adjoint, serving both statements at once.) -/
theorem mk_continuousLinearMaps : #(H →L[ℝ] H) = continuum := by
  sorry

theorem mk_selfAdjoint :
    #{T : H →L[ℝ] H // IsSelfAdjoint T} = continuum := by
  sorry

/-! ### Part B: the CH enumerations -/

section CH

/-- The continuum hypothesis, as a hypothesis. -/
variable (hCH : continuum = aleph 1)

/-- B1. Under CH, the closed subspaces of `H` are enumerated by the
    countable ordinals: there is a surjection from `{o : Ordinal // o <
    ω₁}` onto them. Deliver this in the exact shape WO-9's `E1`
    (`PlufWO9.exists_enumeration_of_CH`) and `E2`
    (`PlufWO9.exists_omega1_chain`) consume — the WO-9 report's signature
    table is the reference, and if E1 already delivers the general
    statement, B1–B3 are instantiations rather than new proofs. REPORT
    which. -/
theorem exists_enum_closedSubspaces :
    ∃ f : {o : Ordinal // o < (aleph 1).ord} → {M : Submodule ℝ H // IsClosed (M : Set H)},
      Function.Surjective f := by
  sorry

/-- B2. Under CH, the ℕ-indexed orthonormal bases are enumerated by the
    countable ordinals. (This is what Paper II's Theorem 5.4 recursion
    consumes: one basis defeated per stage.) -/
theorem exists_enum_hilbertBases :
    ∃ f : {o : Ordinal // o < (aleph 1).ord} → HilbertBasis ℕ ℝ H,
      Function.Surjective f := by
  sorry

/-- B3. Under CH, the self-adjoint operators are enumerated by the
    countable ordinals. (This is what Paper I's Theorem 5.7 recursion
    consumes: one operator rounded per stage.) -/
theorem exists_enum_selfAdjoint :
    ∃ f : {o : Ordinal // o < (aleph 1).ord} → {T : H →L[ℝ] H // IsSelfAdjoint T},
      Function.Surjective f := by
  sorry

end CH

/-! ### Part C: stage bookkeeping -/

/-- C1. Every proper initial segment of ω₁ is countable. This is the fact
    that makes the recursions work: at stage `α`, the data accumulated so
    far is indexed by `{β // β < α}`, which is countable, so a countable
    construction suffices to pass to the next stage. -/
theorem countable_Iio_of_lt_omega1 {α : Ordinal} (hα : α < (aleph 1).ord) :
    (Set.Iio α).Countable := by
  sorry

/-- C2. A countable union of countable sets indexed below a countable
    ordinal is countable — the closure property each limit stage needs.
    (If this is immediate from C1 plus Mathlib's `Set.Countable.biUnion`,
    state it anyway: the recursions will cite it directly, and having it
    named saves the caller the assembly.) -/
theorem countable_iUnion_Iio {α : Ordinal} (hα : α < (aleph 1).ord)
    (s : Ordinal → Set H) (hs : ∀ β, (s β).Countable) :
    (⋃ β ∈ Set.Iio α, s β).Countable := by
  sorry

/-- C3. The span of a countable set of vectors is separable, and its
    closure is a proper closed subspace whenever the set is countable and
    `H` is infinite-dimensional — the fact that leaves room at each stage.
    State the form the recursions want: a countable family of vectors
    never spans `H` densely enough to exhaust it, i.e. its closed span has
    an orthogonal complement of infinite dimension, OR at minimum is not
    all of `H`. The stronger form (infinite-dimensional complement) is
    what the ampleness arguments of Paper I §5 will need; supply it if it
    is no harder, and REPORT which was proved. -/
theorem exists_orthogonal_of_countable (s : Set H) (hs : s.Countable) :
    True := by
  sorry

/-! ### Axiom audit -/

#print axioms mk_closedSubspaces
#print axioms mk_hilbertBases
#print axioms mk_continuousLinearMaps
#print axioms mk_selfAdjoint
#print axioms exists_enum_closedSubspaces
#print axioms exists_enum_hilbertBases
#print axioms exists_enum_selfAdjoint
#print axioms countable_Iio_of_lt_omega1
#print axioms countable_iUnion_Iio
#print axioms exists_orthogonal_of_countable

end PlufWO11
