/-
  PlufWO1.lean — Work Order 1 for the pluf project (Feldman–Wilce).

  Scope: (A) σ-Q-point combinatorics for ultrafilters on a well-ordered type,
         including normal ⇒ σ-Q via the piece-minima argument;
         (B) the witness subspace W in ℓ²(ℕ) and the thinness lemma
         (blockers meet every piece-block in rank ≤ 1);
         (C) [stretch] the no-disjointly-supported-blocker proposition.

  Ground rules (see WORKORDER.md): statements below are the mathematical
  contract. Renaming, reordering, and adaptation to current Mathlib idiom are
  welcome; CHANGES TO MATHEMATICAL CONTENT ARE NOT — if a statement appears
  false or unstatable, REPORT rather than repair. Final deliverable must be
  sorry/admit/axiom/native_decide-free with #print axioms output for every
  theorem, whitelist: propext, Classical.choice, Quot.sound.

  Toolchain: leanprover/lean4:v4.28.0 with matching Mathlib.
-/
import Mathlib

open Set

namespace PlufWO1

/-! ### Part A: σ-Q-points -/

section SigmaQ

variable {κ : Type*} [LinearOrder κ] [WellFoundedLT κ]

/-- A partial selector meets each piece of a family at most once. -/
def IsPartialSelector (S : Set κ) {ι : Type*} (P : ι → Set κ) : Prop :=
  ∀ i, (S ∩ P i).Subsingleton

/-- `U` is a σ-Q-point: every countable-to-one function is injective on a
    set of `U`. This is the κ-analogue of the Q-point property, with
    "finite-to-one" promoted to "countable-to-one". -/
def SigmaQPoint (U : Ultrafilter κ) : Prop :=
  ∀ g : κ → κ, (∀ y, (g ⁻¹' {y}).Countable) → ∃ S ∈ U, Set.InjOn g S

/-- `U` has the Fodor property: every function regressive on a set of `U`
    is constant on a set of `U`. (For a normal measure this is the standard
    Fodor/pressing-down lemma; we take it as the defining hypothesis so that
    Part A is free of large-cardinal machinery.) -/
def FodorProperty (U : Ultrafilter κ) : Prop :=
  ∀ f : κ → κ, {x | f x < x} ∈ U → ∃ y, {x | f x = y} ∈ U

/-- A1. Union of two non-members of an ultrafilter is a non-member.
    (Likely in Mathlib as `Ultrafilter.union_mem_iff` or derivable in one
    line; locate or prove.) -/
theorem not_mem_union_of_not_mem (U : Ultrafilter κ) {A B : Set κ}
    (hA : A ∉ U) (hB : B ∉ U) : A ∪ B ∉ U := by
  sorry

/-- A2 (partition form ⇒ function form). If every partition of `κ` into
    countable nonempty pieces admits a partial selector in `U`, then `U` is a
    σ-Q-point. (The pieces are the fibers of `g`; injectivity on `S` is the
    selector property.) -/
theorem sigmaQ_of_partition_selectors (U : Ultrafilter κ)
    (h : ∀ {ι : Type} (P : ι → Set κ), Pairwise (Function.onFun Disjoint P) →
      (∀ i, (P i).Countable) → (∀ i, (P i).Nonempty) →
      (⋃ i, P i) = univ → ∃ S ∈ U, IsPartialSelector S P) :
    SigmaQPoint U := by
  sorry

/-- A2′ (function form ⇒ partition form). The converse: from σ-Q-ness,
    selectors for every partition into countable nonempty pieces, via the
    least-element-of-my-piece function. -/
theorem partition_selectors_of_sigmaQ (U : Ultrafilter κ)
    (hU : SigmaQPoint U) {ι : Type} (P : ι → Set κ)
    (hdisj : Pairwise (Function.onFun Disjoint P))
    (hctble : ∀ i, (P i).Countable) (hne : ∀ i, (P i).Nonempty)
    (hcover : (⋃ i, P i) = univ) :
    ∃ S ∈ U, IsPartialSelector S P := by
  sorry

/-- A3 (normal ⇒ σ-Q, sharp form). Under the Fodor property and countable
    incompleteness-avoidance (no countable set in `U`), the set of
    piece-minima of any partition into countable nonempty pieces lies in `U`
    — and it is a partial selector. Consequently `U` is a σ-Q-point.

    Proof sketch (paper: Paper III, Lemma 5.2): let `M` be the set of points
    that are the `<`-minimum of their piece. If `M ∉ U` then
    `x ↦ min (piece of x)` is regressive on `κ \ M ∈ U`, hence constant on a
    set of `U` by Fodor, trapping a set of `U` inside one countable piece —
    contradiction. -/
theorem minima_mem_of_fodor (U : Ultrafilter κ)
    (hfodor : FodorProperty U)
    (hcc : ∀ s : Set κ, s.Countable → s ∉ U)
    {ι : Type} (P : ι → Set κ)
    (hdisj : Pairwise (Function.onFun Disjoint P))
    (hctble : ∀ i, (P i).Countable) (hne : ∀ i, (P i).Nonempty)
    (hcover : (⋃ i, P i) = univ) :
    ∃ S ∈ U, IsPartialSelector S P := by
  sorry

/-- A3′ packaging. -/
theorem sigmaQ_of_fodor (U : Ultrafilter κ)
    (hfodor : FodorProperty U)
    (hcc : ∀ s : Set κ, s.Countable → s ∉ U) :
    SigmaQPoint U := by
  sorry

/-- A4 (transversal escape). Pairwise disjoint sets each containing two
    points admit a transversal outside the ultrafilter: choose two disjoint
    transversals; at most one lies in `U`. -/
theorem exists_transversal_not_mem (U : Ultrafilter κ) {ι : Type*}
    (σ : ι → Set κ) (hdisj : Pairwise (Function.onFun Disjoint σ))
    (h2 : ∀ i, ∃ a b, a ∈ σ i ∧ b ∈ σ i ∧ a ≠ b) :
    ∃ D : Set κ, (∀ i, (D ∩ σ i).Nonempty) ∧ D ∉ U := by
  sorry

end SigmaQ

/-! ### Part B: the witness subspace in ℓ²(ℕ) and the thinness lemma -/

section Hilbert

noncomputable section

/-- The ambient Hilbert space ℓ²(ℕ; ℝ). -/
abbrev H : Type := lp (fun _ : ℕ => ℝ) 2

/-- B1a. The weight sequence restricted to a set `A ⊆ ℕ` is
    square-summable, so defines an element of `H` with support exactly `A`:
    coordinates `2^{-(n+1)}` on `A`, zero off `A`. -/
def constraintVec (A : Set ℕ) : H := sorry

theorem constraintVec_apply (A : Set ℕ) (n : ℕ) :
    (constraintVec A : ∀ _ : ℕ, ℝ) n =
      if n ∈ A then ((2 : ℝ) ^ (n + 1))⁻¹ else 0 := by
  sorry

theorem constraintVec_ne_zero {A : Set ℕ} (hA : A.Nonempty) :
    constraintVec A ≠ 0 := by
  sorry

/-- B1b. The block of a set `S ⊆ ℕ`: the closed subspace of vectors
    supported in `S`. (Closedness is B1c below; state it as a `Submodule`
    plus a separate closedness lemma, or as whatever packaging current
    Mathlib makes most natural — e.g. an intersection of kernels of the
    coordinate functionals. The membership characterization is the
    contract.) -/
def block (S : Set ℕ) : Submodule ℝ H := sorry

theorem mem_block_iff (S : Set ℕ) (x : H) :
    x ∈ block S ↔ ∀ n ∉ S, (x : ∀ _ : ℕ, ℝ) n = 0 := by
  sorry

/-- B1c. Blocks are closed. -/
theorem isClosed_block (S : Set ℕ) : IsClosed (block S : Set H) := by
  sorry

/-- B1d. Inner product against a constraint vector sees only the
    coordinates in its support: if `x` is supported in a set disjoint from
    `A`, then `⟪x, constraintVec A⟫ = 0`. -/
theorem inner_constraintVec_eq_zero_of_disjoint {A S : Set ℕ}
    (hdisj : Disjoint A S) {x : H} (hx : x ∈ block S) :
    inner (𝕜 := ℝ) x (constraintVec A) = 0 := by
  sorry

/-- The witness subspace of a partition `A : ℕ → Set ℕ`:
    everything orthogonal to every constraint vector. -/
def W (A : ℕ → Set ℕ) : Submodule ℝ H :=
  ⨅ k, LinearMap.ker
    ((innerSL ℝ (constraintVec (A k)) : H →L[ℝ] ℝ) : H →ₗ[ℝ] ℝ)

theorem mem_W_iff (A : ℕ → Set ℕ) (x : H) :
    x ∈ W A ↔ ∀ k, inner (𝕜 := ℝ) x (constraintVec (A k)) = 0 := by
  sorry

/-- B2 (Thinness Lemma; Paper II, Lemma 3.6). Let `A` be a partition of ℕ
    into pairwise disjoint nonempty pieces. If a submodule `R` meets `W A`
    trivially, then `R` meets each piece-block in rank at most one.

    Proof sketch: on `R ⊓ block (A k)`, the linear functional
    `x ↦ ⟪x, constraintVec (A k)⟫` is injective — a vector in its kernel is
    orthogonal to `constraintVec (A k)` by assumption and to every other
    `constraintVec (A j)` automatically (disjoint supports, B1d), hence
    lies in `R ⊓ W A = ⊥`. An injective linear map into ℝ bounds the rank
    by one. -/
theorem thin (A : ℕ → Set ℕ)
    (hdisj : Pairwise (Function.onFun Disjoint A))
    (R : Submodule ℝ H) (hRW : R ⊓ W A = ⊥) (k : ℕ) :
    Module.rank ℝ ↥(R ⊓ block (A k)) ≤ 1 := by
  sorry

/-! ### Part C (stretch): no disjointly supported blocker -/

/-- Support of a vector. -/
def supp (x : H) : Set ℕ := {n | (x : ∀ _ : ℕ, ℝ) n ≠ 0}

/-- C1 (structure of block intersections for disjointly supported spans).
    If the `ρ i` are nonzero with pairwise disjoint supports, then the
    closed span meets a block exactly in the closed span of the wholly
    supported generators. Only the forward inclusion is nontrivial; it
    rests on the orthonormal expansion of elements of the closed span
    along the normalized `ρ i` and continuity of coordinates. -/
theorem closure_span_inter_block {ι : Type} (ρ : ι → H)
    (hρ : ∀ i, ρ i ≠ 0)
    (hdisj : Pairwise (Function.onFun Disjoint (fun i => supp (ρ i))))
    (S : Set ℕ) :
    (Submodule.span ℝ (Set.range ρ)).topologicalClosure ⊓ block S =
      (Submodule.span ℝ {v | ∃ i, v = ρ i ∧ supp (ρ i) ⊆ S}).topologicalClosure := by
  sorry

/-- C2 (No disjointly supported blocker; Paper II, Proposition 3.7).
    Hypotheses: `A` a partition of ℕ into pairwise disjoint nonempty
    pieces covering ℕ, with no partial selector in the ultrafilter `U`;
    `ρ` a family of nonzero vectors with pairwise disjoint supports whose
    closed span `R` meets `W A` trivially. Conclusion: some `S ∈ U` has
    `R ⊓ block S = ⊥`.

    Proof sketch (paper): by C1 it suffices to find `S ∈ U` containing no
    support. Singleton supports are (multiples of) basis vectors; two of
    them in one piece produce an explicit element of `R ⊓ W A`, so the
    singleton-support points form a partial selector `D_s ∉ U`. The
    multi-point supports admit a transversal `D₁ ∉ U` (A4). Then
    `D = D_s ∪ D₁ ∉ U` (A1) meets every support, and `S = Dᶜ ∈ U` works. -/
theorem noblock (U : Ultrafilter ℕ) (A : ℕ → Set ℕ)
    (hdisjA : Pairwise (Function.onFun Disjoint A))
    (hneA : ∀ k, (A k).Nonempty) (hcover : (⋃ k, A k) = univ)
    (hsel : ∀ S ∈ U, ¬ IsPartialSelector S A)
    {ι : Type} (ρ : ι → H) (hρ : ∀ i, ρ i ≠ 0)
    (hdisjρ : Pairwise (Function.onFun Disjoint (fun i => supp (ρ i))))
    (hRW : (Submodule.span ℝ (Set.range ρ)).topologicalClosure ⊓ W A = ⊥) :
    ∃ S ∈ U,
      (Submodule.span ℝ (Set.range ρ)).topologicalClosure ⊓ block S = ⊥ := by
  sorry

end

end Hilbert

end PlufWO1
