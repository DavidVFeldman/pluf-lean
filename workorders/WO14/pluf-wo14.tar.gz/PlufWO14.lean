/-
  PlufWO14.lean — Work Order 14 for the pluf project (Feldman–Wilce).

  Scope: Paper I, Lemma 5.6 — the BLOCKING LEMMA, the technical heart of
  the paper and the hardest single item of this campaign. Decomposed as:
    (S) the selection lemmas — the recursion's inner loop, consuming
        WO-13's interface exactly as its report prescribes;
    (P) the perturbation lemma — the odd-stage algebra that replaces the
        orthogonal decomposition non-distributivity forbids;
    (W) the recursion, the exact-diagonality lemma, and the assembly.

  QUARANTINE FALLBACK (per the standing WO-7a recommendation). If the
  recursion W1 cannot be closed, DO NOT abandon the commission: deliver
  S0–S3, P1, W2, and W3 in the conditional form
  `blocking_lemma_of_sequence` (W3 with W1's conclusion as a hypothesis),
  and report precisely where W1 failed. That converts the blocking lemma
  into a named quarantined hypothesis with its entire consumption
  machine-checked, which is the sanctioned fallback. W3 as contracted
  below is the unconditional composition and is the primary target.

  DESIGN NOTES BOUND INTO THE CONTRACTS (read before the census):

  1. THE RAYLEIGH-ONLY DISCIPLINE. The selection lemmas conclude with the
     Rayleigh estimate `|⟪T w, w⟫ − λ| ≤ ε`, NOT with a defect-norm bound
     `‖T w − λ w‖ ≤ ε` in H. This is deliberate: S1's proof routes
     through the compression to a finite-codimension cut, and Rayleigh
     values transfer exactly through compressions
     (`⟪(compress C) u, u⟫ = ⟪T u, u⟫`) while defect norms do not. The
     recursion's clause (a) consumes only Rayleigh, so nothing is lost.
     Do not strengthen S1's conclusion to a defect bound: it is not
     provable by this route and is not needed.

  2. WHERE ESCAPE IS AND IS NOT AVAILABLE. The blocked value λ₀ (the one
     with `λ₀ ∉ essSpec (compress (q ⊓ N))`) supports the full
     escape-based selection S2; the OTHER value λ₁ does not — nothing
     excludes `λ₁ ∈ essSpec (compress (h ⊓ N))` — and the odd stage must
     go through P1's perturbation instead. A draft that applies S2 at λ₁
     is wrong even if it elaborates.

  3. THE UNUSED HYPOTHESIS. The paper's statement carries
     "g ⊓ N ≠ ⊥ for all g ∈ G". It is contracted for fidelity and is
     expected to be flagged unused: the proof never consumes it, and even
     the degenerate `q ⊓ N = ⊥` needs nothing extra, since
     `PlufWO13.notMem_essSpec_compress_bot` makes BOTH values missing
     there. Retain and flag, per protocol.

  4. KNOWN DUPLICATION. W0 (decreasing cofinal chains in a countable
     directed family) is also contracted as WO-12's B2, running in
     parallel. The duplication is accepted and will be reconciled at
     merge; do not import from WO-12.

  Base: the merged tree after WO-13 (216 theorems; CI runs #1–#12).
  `PlufWO14.lean` imports `RequestProject.PlufWO13`. All prior theorems
  must remain green; `PlufWO7a.lean` is the census record, not to be
  edited.

  Toolchain: leanprover/lean4:v4.28.0, Mathlib pinned as in the repo.
-/
import RequestProject.PlufWO13

open Set PlufWO13

namespace PlufWO14

abbrev H := PlufWO1.H

/-! ### Part S: the selection lemmas (the inner loop) -/

/-- S0 (constraint cutting, quotient form). Finitely many continuous
    linear functionals cut a closed subspace down to a closed subspace of
    finite codimension, in the exact quotient shape WO-13's C2 consumes:
    `Module.Finite ℝ (↥V ⧸ (C.comap V.subtype))`. The census should first
    check `PlufWO13/Basic.lean`, whose finiteness-transfer lemmas may
    already contain this; if so, cite rather than reprove, and report. -/
theorem finCodim_of_constraints (V : Submodule ℝ H)
    (hV : IsClosed (V : Set H)) (F : Finset (H →L[ℝ] ℝ)) :
    IsClosed ((V ⊓ ⨅ f ∈ F, LinearMap.ker (f : H →ₗ[ℝ] ℝ) : Submodule ℝ H) : Set H) ∧
    Module.Finite ℝ
      (↥V ⧸ ((V ⊓ ⨅ f ∈ F, LinearMap.ker (f : H →ₗ[ℝ] ℝ)).comap V.subtype)) := by
  sorry

/-- S1 (constrained selection at an essential-spectrum value). If
    `λ ∈ essSpec (compress V)` for closed `V`, then inside `V`, subject to
    finitely many linear constraints, there is a unit vector with Rayleigh
    value within `ε` of `λ`.

    Route: S0 cuts `V` to a finite-codimension closed `C`;
    `PlufWO13.essSpec_compress_eq_of_finCodim` keeps
    `λ ∈ essSpec (compress C)`; WO-9's
    `exists_orthonormal_approx_eigenvectors` applied on the ambient
    space `↥C` with operator `compress C` produces an orthonormal
    approximate eigenvector `u` with defect `< ε` FOR THE COMPRESSION;
    the Rayleigh value transfers exactly
    (`⟪(compress C) u, u⟫ = ⟪T u, u⟫` — the projection is absorbed by
    `u ∈ C`), and Cauchy–Schwarz (WO-13's D2 pattern, applied on `↥C`)
    converts the compression defect to the Rayleigh estimate. Per design
    note 1, the conclusion is Rayleigh-only. -/
theorem exists_unit_constrained_rayleigh (V : Submodule ℝ H)
    (hV : IsClosed (V : Set H)) {lam : ℝ}
    (hlam : lam ∈ PlufWO9.essSpec (compress V))
    (F : Finset (H →L[ℝ] ℝ)) {ε : ℝ} (hε : 0 < ε) :
    ∃ w : H, w ∈ V ∧ ‖w‖ = 1 ∧ (∀ f ∈ F, f w = 0) ∧
      |inner (𝕜 := ℝ) (T w) w - lam| ≤ ε := by
  sorry

/-- S2 (constrained selection off `N`, at the blocked value). Under the
    escape hypotheses — `V` ample, `N` closed,
    `λ ∈ {1, 1/16}` with `λ ∉ essSpec (compress (V ⊓ N))` — the selection
    of S1 can additionally avoid `N`.

    Route (this is the WO-13 report's prescription, verbatim):
    `PlufWO13.escape` at tolerance `ε` yields `K ≤ V`, closed,
    infinite-dimensional, with the homogeneous bound and with `K ⊓ N` of
    infinite codimension in `K`. S0 cuts `K` by the constraints to a
    finite-codimension closed `C ≤ K`; then `C ⊄ N` — else `C ≤ K ⊓ N`,
    finite codimension trapped inside infinite codimension — so a unit
    `w ∈ C \ N` exists; the homogeneous bound holds at `w` since `w ∈ K`,
    and `PlufWO13.quadratic_estimate_of_bound` gives the Rayleigh
    estimate. Note `escape`'s `hVN : ¬ Ample (V ⊓ N)` binder is supplied
    from `hnot` (a missing value already refutes ampleness); do not add
    it as a hypothesis here. -/
theorem exists_unit_constrained_rayleigh_notMem (V N : Submodule ℝ H)
    (hV : Ample V) (hN : IsClosed (N : Set H)) {lam : ℝ}
    (hlam : lam = 1 ∨ lam = 1/16)
    (hnot : lam ∉ PlufWO9.essSpec (compress (V ⊓ N)))
    (F : Finset (H →L[ℝ] ℝ)) {ε : ℝ} (hε : 0 < ε) :
    ∃ w : H, w ∈ V ∧ ‖w‖ = 1 ∧ (∀ f ∈ F, f w = 0) ∧ w ∉ N ∧
      |inner (𝕜 := ℝ) (T w) w - lam| ≤ ε := by
  sorry

/-! ### Part P: the perturbation lemma (the odd stage) -/

/-- P1. Let `w', z` be orthonormal with `⟪T w', z⟫ = 0`, and `z ∉ N` for
    closed `N`. For every `ε > 0` there is `η > 0` such that
    `w = (1 + η^2)^(-1/2) • (w' + η • z)` satisfies:
      (i)   `‖w‖ = 1`;
      (ii)  `f w = 0` for every continuous linear `f` vanishing at both
            `w'` and `z` — so every linear constraint they share;
      (iii) `w ∉ N` (equivalently `P_{Nᗮ} w ≠ 0`);
      (iv)  `|⟪T w, w⟫ − ⟪T w', w'⟫| ≤ ε`.

    The algebra: over ℝ, self-adjointness of `T` turns `⟪T w', z⟫ = 0`
    into the vanishing of BOTH cross terms, so
    `⟪T w, w⟫ = (⟪T w', w'⟫ + η² ⟪T z, z⟫) / (1 + η²)`, whence
    `|⟪T w, w⟫ − ⟪T w', w'⟫| ≤ η²` by `PlufWO13.T_bounds` (the Rayleigh
    values lie in `[1/16, 1]`, so their difference is at most `1`, and
    the displacement is `η²/(1+η²)`-scaled). For (iii): the set of `η`
    with `P_{Nᗮ}(w' + η z) = 0` is at most a single point, since
    `P_{Nᗮ} z ≠ 0`; every sufficiently small positive `η` off that point
    works. This lemma replaces the orthogonal decomposition of the stage
    subspace along `N`, which non-distributivity forbids — it is the
    paper's own remark, and the reason the odd stage exists. -/
theorem perturb_unit (w' z : H) (hw' : ‖w'‖ = 1) (hz : ‖z‖ = 1)
    (horth : inner (𝕜 := ℝ) w' z = 0)
    (hTorth : inner (𝕜 := ℝ) (T w') z = 0)
    (N : Submodule ℝ H) (hN : IsClosed (N : Set H)) (hzN : z ∉ N)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ w : H, ‖w‖ = 1 ∧
      (∀ f : H →L[ℝ] ℝ, f w' = 0 → f z = 0 → f w = 0) ∧
      w ∉ N ∧
      |inner (𝕜 := ℝ) (T w) w - inner (𝕜 := ℝ) (T w') w'| ≤ ε := by
  sorry

/-! ### Part W: the recursion and the assembly -/

/-- W0 (decreasing cofinal chains; duplicate of WO-12's B2, accepted).
    A countable downward directed family of subspaces containing `q`
    admits a decreasing sequence of MEMBERS starting below `q` and
    cofinal in the family. -/
theorem exists_decreasing_cofinal {G : Set (Submodule ℝ H)}
    (hctble : G.Countable) {q : Submodule ℝ H} (hq : q ∈ G)
    (hdir : ∀ M ∈ G, ∀ M' ∈ G, ∃ P ∈ G, P ≤ M ⊓ M') :
    ∃ h : ℕ → Submodule ℝ H, (∀ n, h n ∈ G) ∧ (∀ n, h (n+1) ≤ h n) ∧
      h 0 ≤ q ∧ ∀ M ∈ G, ∃ n, h n ≤ M := by
  sorry

/-- W1 (the blocking sequence — THE RECURSION, and the risk concentration
    of the commission). Let `h : ℕ → Submodule ℝ H` be a decreasing
    sequence of ample subspaces, `N` closed, and `λ₀ ∈ {1, 1/16}` with
    `λ₀ ∉ essSpec (compress (h 0 ⊓ N))`; write `λ₁` for the other value.
    Then there is `w : ℕ → H` with:
      (i)   `w n ∈ h n` for every `n`;
      (ii)  `Orthonormal ℝ w`;
      (iii) `inner (T (w m)) (w n) = 0` for all `m ≠ n`;
      (iv)  `w n ∉ N`, and the vectors `y n = (Nᗮ-projection of w n)` are
            pairwise orthogonal — deliver this clause in the form the
            assembly consumes: `∀ m ≠ n, ⟪P_{Nᗮ}(w m), P_{Nᗮ}(w n)⟫ = 0`
            together with `P_{Nᗮ}(w n) ≠ 0`;
      (v)   `|⟪T (w n), w n⟫ − μ n| ≤ 1/(n+1)`, where `μ n = λ₀` for even
            `n` and `μ n = λ₁` for odd `n` (any ε-sequence tending to 0
            is acceptable; `1/(n+1)` is contracted for definiteness —
            restate the rate if another is cleaner, and report).

    Stage `n`, even: apply S2 in `V = h n` at `λ₀` — the hypothesis
    `λ₀ ∉ essSpec (compress (h n ⊓ N))` descends from `h 0 ⊓ N` by the
    contrapositive of `PlufWO13.essSpec_compress_mono` — with the linear
    constraints `w ⊥ w j`, `w ⊥ T (w j)`, `w ⊥ P_{Nᗮ}(w j)` for `j < n`
    (each is a continuous functional; note `⟪w, T (w j)⟫ = 0` yields
    clause (iii) in both orders by self-adjointness, and
    `⟪w, P_{Nᗮ}(w j)⟫ = 0` yields the `y`-orthogonality since
    `⟪y n, y j⟫ = ⟪w n, P_{Nᗮ}(w j)⟫` — the projection is idempotent and
    self-adjoint and `y j ∈ Nᗮ`).

    Stage `n`, odd: S1 in `h n` at `λ₁` (available: `h n` ample) with the
    same constraints and tolerance `1/(2(n+1))` gives `w'`; S2 in `h n`
    at `λ₀` with the same constraints PLUS `z ⊥ w'` and `z ⊥ T w'` gives
    `z ∉ N`; P1 with `ε = 1/(2(n+1))` produces `w n`, whose shared-
    constraint clause (P1(ii)) covers every stage constraint, whose (iii)
    gives `w n ∉ N`, and whose (iv) lands the Rayleigh value within
    `1/(n+1)` of `λ₁`.

    Per design note 2: S2 is applied ONLY at `λ₀`, never at `λ₁`. -/
theorem exists_blocking_sequence (h : ℕ → Submodule ℝ H)
    (hmono : ∀ n, h (n+1) ≤ h n) (hamp : ∀ n, Ample (h n))
    (N : Submodule ℝ H) (hN : IsClosed (N : Set H))
    {lam₀ lam₁ : ℝ}
    (hpair : (lam₀ = 1 ∧ lam₁ = 1/16) ∨ (lam₀ = 1/16 ∧ lam₁ = 1))
    (hnot : lam₀ ∉ PlufWO9.essSpec (compress (h 0 ⊓ N))) :
    ∃ w : ℕ → H,
      (∀ n, w n ∈ h n) ∧
      Orthonormal ℝ w ∧
      (∀ m n, m ≠ n → inner (𝕜 := ℝ) (T (w m)) (w n) = 0) ∧
      (∀ n, w n ∉ N) ∧
      (∀ m n, m ≠ n →
        inner (𝕜 := ℝ) ((Nᗮ).starProjection (w m)) ((Nᗮ).starProjection (w n)) = 0) ∧
      (∀ n, |inner (𝕜 := ℝ) (T (w n)) (w n) - (if Even n then lam₀ else lam₁)|
        ≤ 1 / (n + 1)) := by
  sorry

/-- W2 (exact diagonality of compressions; the paper's highlighted point
    — "no error accumulates"). Let `w : ℕ → H` be orthonormal with
    `⟪T (w m), w n⟫ = 0` for `m ≠ n`, and let
    `R j = closed span {w n : n ≥ j}`. Then each `w m` (`m ≥ j`) is an
    EXACT eigenvector of the compression of `T` to `R j`, with eigenvalue
    the diagonal entry `d m = ⟪T (w m), w m⟫`.

    (The compression of `T (w m)` expands over the orthonormal basis
    `(w n)_{n ≥ j}` of `R j` with coefficients `⟪T (w m), w n⟫`, all of
    which vanish except the diagonal one.) State against
    `PlufWO13.compress` — the exact packaging of "eigenvector of the
    compression" (an identity in `↥(R j)`, or
    `(R j).starProjection (T (w m)) = d m • w m` in `H`) is the prover's
    choice; report it, and choose the form W3's essential-spectrum step
    consumes most directly. -/
theorem compress_exact_diagonal (w : ℕ → H) (hw : Orthonormal ℝ w)
    (hT : ∀ m n, m ≠ n → inner (𝕜 := ℝ) (T (w m)) (w n) = 0) (j m : ℕ)
    (hm : j ≤ m) :
    ((Submodule.span ℝ (Set.range fun n : {n // j ≤ n} => w n)).topologicalClosure).starProjection
        (T (w m))
      = (inner (𝕜 := ℝ) (T (w m)) (w m)) • w m := by
  sorry

/-- W3 (Paper I, Lemma 5.6 — the blocking lemma, verbatim). Let `G` be a
    countable, downward directed family of ample subspaces and `N` a
    closed subspace such that `q ⊓ N` is not ample for some `q ∈ G` while
    `g ⊓ N ≠ ⊥` for all `g ∈ G` (this last per design note 3: contracted
    for fidelity, expected unused). Then there is a closed subspace `R`
    with:
      (i)  `R ⊓ N = ⊥`;
      (ii) `R ⊓ g` is ample for every `g ∈ G`, and `R` is ample.

    Assembly. Extract λ₀: `q ⊓ N` is closed and not ample, so either it
    is `⊥` — and `PlufWO13.notMem_essSpec_compress_bot` makes both values
    missing — or one of the two essential-spectrum memberships fails;
    either way fix `λ₀ ∈ {1, 1/16}` with
    `λ₀ ∉ essSpec (compress (q ⊓ N))`. W0 gives the decreasing cofinal
    chain `h` below `q`; the missing value descends to `h 0 ⊓ N` by the
    contrapositive of `essSpec_compress_mono`; W1 gives the sequence
    `w`. Put `R = closed span {w n}` and `R j = closed span {w n : n ≥ j}`.

    (i): for `x = ∑ c n • w n ∈ R`, continuity gives
    `(Nᗮ).starProjection x = ∑ c n • y n` with the `y n` pairwise
    orthogonal and nonzero (W1 (iv)); testing against `y m` shows
    `x ∈ N ⇒ c m ‖y m‖² = 0 ⇒ x = 0`.

    (ii): W2 makes every `w m` (`m ≥ j`) an exact eigenvector of
    `compress (R j)` with eigenvalue `d m`, and W1 (v) makes the even-
    and odd-indexed eigenvalue subsequences converge to `λ₀` and `λ₁`.
    Two orthonormal exact-eigenvalue sequences with eigenvalues tending
    to `λ₀`, `λ₁` witness both memberships in
    `essSpec (compress (R j))` — this is the SAME membership route
    WO-13's A3 used for `T` itself (orthonormal in `↥(R j)`, hence
    weakly null there); if the witnessing criterion is not exported from
    WO-13/WO-9, prove the small bridging lemma and report. So each `R j`
    is ample; `R j ≤ R ⊓ h j` (each `w n ∈ h n ≤ h j` for `n ≥ j`), the
    chain is cofinal in `G`, and `PlufWO13.ample_of_ample_le` promotes
    ampleness to every `R ⊓ g` and, at `j = 0`, to `R` itself. -/
theorem blocking_lemma (G : Set (Submodule ℝ H)) (hctble : G.Countable)
    (hamp : ∀ g ∈ G, Ample g)
    (hdir : ∀ M ∈ G, ∀ M' ∈ G, ∃ P ∈ G, P ≤ M ⊓ M')
    (N : Submodule ℝ H) (hN : IsClosed (N : Set H))
    {q : Submodule ℝ H} (hq : q ∈ G) (hqN : ¬ Ample (q ⊓ N))
    (hGN : ∀ g ∈ G, g ⊓ N ≠ ⊥) :
    ∃ R : Submodule ℝ H, IsClosed (R : Set H) ∧
      R ⊓ N = ⊥ ∧
      (∀ g ∈ G, Ample (R ⊓ g)) ∧
      Ample R := by
  sorry

/-! ### Axiom audit -/

#print axioms finCodim_of_constraints
#print axioms exists_unit_constrained_rayleigh
#print axioms exists_unit_constrained_rayleigh_notMem
#print axioms perturb_unit
#print axioms exists_decreasing_cofinal
#print axioms exists_blocking_sequence
#print axioms compress_exact_diagonal
#print axioms blocking_lemma

end PlufWO14
