/-
  PlufWO4.lean — Work Order 4 for the pluf project (Feldman–Wilce).

  Scope: the fourth paper of the series (products of normal measures), plus
  its ω-lemmas:
    (A) the homogeneity framework and the injectivity-on-a-square theorem;
    (B) the Fubini product as an ultrafilter, its basic largeness facts, the
        full-selector property and its failure for the product, and the
        non-isomorphism packaging;
    (C) the exact-paving property (EPP): paving of the product from
        homogeneity (the centerpiece), EPP ⇒ σ-Q, and the transfer of the
        WO-2/WO-3 theory to EPP hypotheses, instantiated at the product;
    (D) constraints on addable blockers at ℕ: generalized thinness, the
        support lemma, and the Baire piece-spread lemma.

  As always, NO large-cardinal machinery is axiomatized. Rowbottom
  homogeneity, the Fodor property, uncountable pivots, and smallness enter
  only as hypotheses; every theorem below is ZFC.

  This WO builds on the WO-3 artifact (repo `pluf-lean`, CI runs #1–#3
  green; the full project is under `base/`). Reuse `PlufWO1`–`PlufWO3`
  freely (in particular `SigmaQPoint`, `IsPartialSelector`, `FodorProperty`,
  `Hk`, `evec`, `block`, `supp`, `countable_supp`, `coordCLM`,
  `hasSum_coord_smul`, `inner_eq_coord_mul`, `PhiU`, `Wk`, and the WO-1
  Part B witness machinery at ℕ). All 39 prior theorems must remain green.

  Toolchain: leanprover/lean4:v4.28.0, Mathlib pinned as in the repo.
-/
import RequestProject.PlufWO3

open Set PlufWO2 PlufWO3

namespace PlufWO4

/-! ### Part A: homogeneity and injectivity on a square -/

section Homog

variable {κ : Type*} [LinearOrder κ]

/-- Rowbottom homogeneity for `n`-tuples: every finite coloring of the
    strictly increasing `n`-tuples is constant on the increasing tuples
    from a set of `D`. For a normal measure this is Rowbottom's theorem;
    here it is a hypothesis, so everything is ZFC. -/
def RowbottomFor (D : Ultrafilter κ) (n : ℕ) : Prop :=
  ∀ {C : Type} [Fintype C] [Nonempty C] (F : (Fin n → κ) → C),
    ∃ H ∈ D, ∃ c : C, ∀ t : Fin n → κ,
      StrictMono t → (∀ i, t i ∈ H) → F t = c

/-- Every set of `D` contains a point with uncountably many predecessors
    in the set. (For a normal measure on a measurable cardinal this is
    immediate from the order type; taken as a hypothesis.) -/
def UncountablePivots (D : Ultrafilter κ) : Prop :=
  ∀ S ∈ D, ∃ β ∈ S, ¬ (S ∩ Set.Iio β).Countable

/-- A1 (Injectivity on a square; Paper IV, Theorem 3.1, countable-fiber
    form). If `g` on the increasing pairs has countable fibers, then `g`
    is injective on the increasing pairs from some `H ∈ D`.

    Proof (paper): homogenize simultaneously the finitely many equality
    patterns of `g` on increasing triples and quadruples. Each
    identification pattern is impossible: patterns with a coordinate free
    to vary upward put κ-many pairs in one fiber; patterns whose free
    coordinate lies below a fixed one put uncountably many pairs in one
    fiber, by choosing the pivot via `UncountablePivots`. Hence all
    homogeneous patterns are ``all distinct'' and `g` is injective on
    `[H]²`. (`V` may live in any universe convenient for the proof;
    lifting is free.) -/
theorem inj_on_pairs (D : Ultrafilter κ)
    (h3 : RowbottomFor D 3) (h4 : RowbottomFor D 4)
    (hpiv : UncountablePivots D) {V : Type*} (g : κ → κ → V)
    (hfib : ∀ v : V, {p : κ × κ | p.1 < p.2 ∧ g p.1 p.2 = v}.Countable) :
    ∃ H ∈ D, ∀ a ∈ H, ∀ b ∈ H, ∀ a' ∈ H, ∀ b' ∈ H,
      a < b → a' < b' → g a b = g a' b' → a = a' ∧ b = b' := by
  sorry

end Homog

/-! ### Part B: the Fubini product -/

section Fubini

variable {κ : Type*} [LinearOrder κ]

/-- The Fubini product of two ultrafilters on `κ`, as an ultrafilter on
    `κ × κ`: a set is large iff `D₁`-many sections are `D₂`-large.
    (If Mathlib already provides this — check `Ultrafilter.prod` and kin
    in the census — use the library object and prove `mem_fubini_iff`
    as the bridging lemma.) -/
noncomputable def fubini (D₁ D₂ : Ultrafilter κ) : Ultrafilter (κ × κ) :=
  sorry

theorem mem_fubini_iff (D₁ D₂ : Ultrafilter κ) (X : Set (κ × κ)) :
    X ∈ fubini D₁ D₂ ↔ {γ | {β | (γ, β) ∈ X} ∈ D₂} ∈ D₁ := by
  sorry

/-- B1. The upper triangle of a set of `D` is large in the self-product.
    Needs that tails `{β | γ < β}` lie in `D`; taken as the hypothesis
    `htail` (true for any uniform/normal ultrafilter on a cardinal). -/
theorem triangle_mem_fubini (D : Ultrafilter κ)
    (htail : ∀ γ : κ, {β | γ < β} ∈ D) {H : Set κ} (hH : H ∈ D) :
    {p : κ × κ | p.1 ∈ H ∧ p.2 ∈ H ∧ p.1 < p.2} ∈ fubini D D := by
  sorry

/-- B2. Countable sets are small in the product, given that they are
    small in each factor. -/
theorem countableSmall_fubini (D : Ultrafilter κ)
    (hcs : ∀ s : Set κ, s.Countable → sᶜ ∈ D) :
    ∀ s : Set (κ × κ), s.Countable → sᶜ ∈ fubini D D := by
  sorry

/-- B3. No column `{γ} × κ` lies in the product. -/
theorem column_notMem_fubini (D : Ultrafilter κ)
    (hpr : ∀ γ : κ, {γ}ᶜ ∈ D) (γ : κ) :
    ({γ} ×ˢ (Set.univ : Set κ)) ∉ fubini D D := by
  sorry

/-- The full-selector property: every partition into pieces outside the
    ultrafilter admits a set of the ultrafilter meeting each piece at
    most once. (No countability restriction; contrast `SigmaQPoint`.)
    This property mentions no order, hence is invariant under
    `Ultrafilter.map` along bijections. -/
def FullSelector {X : Type*} (U : Ultrafilter X) : Prop :=
  ∀ {ι : Type} (P : ι → Set X), Pairwise (Function.onFun Disjoint P) →
    (∀ i, P i ∉ U) → (⋃ i, P i) = univ →
    ∃ S ∈ U, PlufWO1.IsPartialSelector S P

omit [LinearOrder κ] in
/-- B4 (Paper IV, Lemma 2.2). The Fodor property yields full selectors:
    the set of piece-minima lies in `D`. The proof is the certified
    minima argument of WO-1's A3 with countability of the pieces deleted:
    a `D`-large set inside one piece now contradicts `P i ∉ D` directly.
    (State over a well-order as in WO-1; the `omit` here is for the
    section bookkeeping only — reintroduce instances as needed.) -/
theorem fullSelector_of_fodor {κ : Type} [LinearOrder κ] [WellFoundedLT κ]
    (D : Ultrafilter κ) (hfodor : PlufWO1.FodorProperty D) :
    FullSelector D := by
  sorry

/-- B5 (Paper IV, Proposition 2.3, combinatorial half). The self-product
    fails the full-selector property: the column partition has no piece
    in the product, and any partial selector has singleton sections. -/
theorem not_fullSelector_fubini (D : Ultrafilter κ)
    (hpr : ∀ γ : κ, {γ}ᶜ ∈ D) :
    ¬ FullSelector (fubini D D) := by
  sorry

/-- B6. `FullSelector` is invariant under isomorphism of ultrafilters. -/
theorem fullSelector_map_iff {X Y : Type*} (e : X ≃ Y) (U : Ultrafilter X) :
    FullSelector (Ultrafilter.map e U) ↔ FullSelector U := by
  sorry

/-- B7 (Paper IV, Proposition 2.3). The self-product is isomorphic to no
    ultrafilter with the Fodor property on a well-ordered type: transport
    would give it the full-selector property, refuted by B5. -/
theorem fubini_not_iso_fodor (D : Ultrafilter κ)
    (hpr : ∀ γ : κ, {γ}ᶜ ∈ D)
    {κ' : Type} [LinearOrder κ'] [WellFoundedLT κ']
    (V : Ultrafilter κ') (hV : PlufWO1.FodorProperty V)
    (e : (κ × κ) ≃ κ') :
    Ultrafilter.map e (fubini D D) ≠ V := by
  sorry

/-- B8 (Paper IV, Corollary 3.2). The self-product is a σ-Q-point, given
    the Part A hypotheses on `D` (instantiate A1 at the piece-index
    function of a countable-piece partition of the triangle; off-triangle
    points are handled by intersecting with a triangle set). -/
theorem sigmaQ_fubini (D : Ultrafilter κ)
    (h3 : RowbottomFor D 3) (h4 : RowbottomFor D 4)
    (hpiv : UncountablePivots D) (htail : ∀ γ : κ, {β | γ < β} ∈ D) :
    PlufWO1.SigmaQPoint (fubini D D) := by
  sorry

end Fubini

/-! ### Part C: the exact-paving property and the transfer -/

section EPP

variable {X : Type*}

/-- The exact-paving property (Paper IV, Definition 5.1). -/
def EPP (U : Ultrafilter X) : Prop :=
  ∀ c : X → Set X, (∀ x, (c x).Countable) →
    ∃ S ∈ U, ∀ x ∈ S, ∀ y ∈ S, x ≠ y → y ∉ c x

/-- C1 (EPP ⇒ σ-Q; Paper IV, Section 5). Apply EPP to
    `c x = (piece of x) \ {x}`. -/
theorem sigmaQ_of_EPP (U : Ultrafilter X) (hEPP : EPP U) :
    PlufWO1.SigmaQPoint U := by
  sorry

variable {κ : Type*} [LinearOrder κ]

/-- C2 (Exact paving for the product; Paper IV, Theorem 4.1 — the
    centerpiece). Under the Part A hypotheses on `D`, the self-product
    has EPP.

    Proof (paper, in full in the docarchive): identify the triangle with
    the increasing pairs. For each of the finitely many placement
    patterns of an ordered pair of distinct points `x, y` on an
    increasing triple or quadruple, color the triples/quadruples by the
    truth of `y ∈ c x`; homogenize all simultaneously (RowbottomFor 3
    and 4). A homogeneous ``yes'' is impossible in every pattern: fixing
    `x`'s coordinates and freeing a coordinate of `y` upward puts
    κ-many `y`'s into the single countable set `c x`; when `y`'s free
    coordinates lie below a coordinate of `x`, choose that coordinate as
    an uncountable pivot (`UncountablePivots`) to put uncountably many
    `y`'s into `c x`. Hence the triangle of the homogeneous set mutually
    avoids `c`, and it is large by `triangle_mem_fubini`.

    The pattern case analysis is the mathematical content; the paper's
    Section 4 enumerates it. If a pattern is discovered there to be
    missing or wrongly analyzed, REPORT — that is precisely what this
    commission is for. -/
theorem EPP_fubini (D : Ultrafilter κ)
    (h3 : RowbottomFor D 3) (h4 : RowbottomFor D 4)
    (hpiv : UncountablePivots D) (htail : ∀ γ : κ, {β | γ < β} ∈ D) :
    EPP (fubini D D) := by
  sorry

/-- C3 (exact paving of operators from EPP). The conclusion of
    `PlufWO2.exact_paving`, with `DiagInt` replaced by EPP; the countable
    avoidance sets are the supports of `T (evec x)` and
    `T.adjoint (evec x)` (`countable_supp`). Note the WO-2 proof of the
    downstream theorems consumed only this conclusion; C4–C6 make that
    literal. -/
theorem exact_paving_of_EPP (U : Ultrafilter X) (hEPP : EPP U)
    (T : Hk X →L[ℝ] Hk X) :
    ∃ S ∈ U, ∀ α ∈ S, ∀ β ∈ S, α ≠ β →
      inner (𝕜 := ℝ) (T (evec α)) (evec β) = 0 := by
  sorry

/-- C4–C6 (the transfer; Paper IV, Theorem 5.2). The exact dichotomy,
    the diagonal flattening, and the decision property of `PhiU`, each
    with hypotheses `(hEPP : EPP U)` and (where the original used it)
    `CountableSmall`-style smallness, in place of `DiagInt`.

    REFACTORING LICENSE (reportable, as in WO-2's Part D): either
    (i) refactor the internals of `PlufWO2.exact_dichotomy`,
    `PlufWO3.quadratic_flat` and `PlufWO3.PhiU_decides` to a common core
    parametrized by the paving conclusion, re-deriving the existing
    theorems as instances — preferred if cheap, since it makes the
    dependence structure literal — or (ii) prove the EPP versions fresh
    in this namespace, reusing the existing auxiliary lemmas
    (`inner_eq_coord_mul`, `hasSum_coord_smul`, `block_le_of_evec_mem`,
    …) as they stand. Either way, the 39 prior theorems must remain
    green. -/
theorem exact_dichotomy_of_EPP (U : Ultrafilter X) (hEPP : EPP U)
    (hsmall : ∀ s : Set X, s.Countable → sᶜ ∈ U)
    (W : Submodule ℝ (Hk X)) (hW : IsClosed (W : Set (Hk X))) :
    ∃ S ∈ U, block S ≤ W ∨ W ⊓ block S = ⊥ := by
  sorry

theorem quadratic_flat_of_EPP (U : Ultrafilter X) (hEPP : EPP U)
    (T : Hk X →L[ℝ] Hk X) (L : ℝ)
    (hL : ∀ ε > 0, {α | |inner (𝕜 := ℝ) (T (evec α)) (evec α) - L| ≤ ε} ∈ U)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ S ∈ U, ∀ x ∈ block S,
      |inner (𝕜 := ℝ) (T x) x - L * ‖x‖ ^ 2| ≤ ε * ‖x‖ ^ 2 := by
  sorry

theorem PhiU_decides_of_EPP (U : Ultrafilter X) (hEPP : EPP U)
    (hsmall : ∀ s : Set X, s.Countable → sᶜ ∈ U)
    (W : Submodule ℝ (Hk X)) (hW : IsClosed (W : Set (Hk X))) :
    W ∈ PhiU U ∨ ∃ M ∈ PhiU U, W ⊓ M = ⊥ := by
  sorry

/-- C7 (the headline instantiation; Paper IV, Theorem 5.2 at the
    product). Under the Part A/B hypotheses on `D`, the block filter of
    the self-product decides every closed subspace and is nonprincipal:
    together with WO-3's filter axioms (which apply verbatim, being
    generic in the ultrafilter) this exhibits a maximal projection
    filter from an ultrafilter that is isomorphic to no Fodor
    ultrafilter (B7). -/
theorem product_decides (D : Ultrafilter κ)
    (h3 : RowbottomFor D 3) (h4 : RowbottomFor D 4)
    (hpiv : UncountablePivots D) (htail : ∀ γ : κ, {β | γ < β} ∈ D)
    (hcs : ∀ s : Set κ, s.Countable → sᶜ ∈ D)
    (W : Submodule ℝ (Hk (κ × κ))) (hW : IsClosed (W : Set (Hk (κ × κ)))) :
    W ∈ PhiU (fubini D D) ∨ ∃ M ∈ PhiU (fubini D D), W ⊓ M = ⊥ := by
  sorry

end EPP

/-! ### Part D: constraints on blockers at ℕ (Paper IV, Section 6) -/

section Blockers

open PlufWO1

-- Ambient: the WO-1 Part B setting — `H := lp (fun _ : ℕ => ℝ) 2`, the
-- partition `A : ℕ → Set ℕ`, constraint vectors and the witness `W A`.

/-- D1 (Generalized thinness; Paper IV, Lemma 6.1). A subspace meeting
    `W A` trivially meets the block of finitely many pieces in rank at
    most the number of pieces. `F.card` functionals cut codimension at
    most `F.card`; a surviving vector is orthogonal to the remaining
    constraints by disjoint supports, hence lies in `R ⊓ W A = ⊥`.
    (WO-1's `thin` is the case of a singleton.) -/
theorem gen_thin (A : ℕ → Set ℕ)
    (hdisj : Pairwise (Function.onFun Disjoint A))
    (R : Submodule ℝ PlufWO1.H) (hRW : R ⊓ PlufWO1.W A = ⊥)
    (F : Finset ℕ) :
    Module.rank ℝ ↥(R ⊓ PlufWO1.block (⋃ k ∈ F, A k)) ≤ F.card := by
  sorry

/-- D2a (ultrafilter glue). For an ultrafilter containing the cofinite
    filter, a set meets every member in an infinite set iff it is a
    member. -/
theorem inter_infinite_iff_mem (U : Ultrafilter ℕ)
    (hcof : ∀ n : ℕ, ({n}ᶜ : Set ℕ) ∈ U) (T : Set ℕ) :
    (∀ S ∈ U, (T ∩ S).Infinite) ↔ T ∈ U := by
  sorry

/-- D2b (rank of a finite block). -/
theorem rank_le_of_le_block_finite {T : Set ℕ} (hT : T.Finite)
    (R : Submodule ℝ PlufWO1.H) (hR : R ≤ PlufWO1.block T) :
    Module.rank ℝ ↥R ≤ hT.toFinset.card := by
  sorry

/-- D2 (Support lemma; Paper IV, Lemma 6.2). If every vector of `R` is
    supported in `T`, and for every `S ∈ U` the space `R ⊓ block S` has
    infinite rank, then `T ∈ U`. (Contrapositive via D2a and D2b:
    otherwise some `S ∈ U` has `T ∩ S` finite, and
    `R ⊓ block S ≤ block (T ∩ S)` has finite rank.) -/
theorem support_mem (U : Ultrafilter ℕ)
    (hcof : ∀ n : ℕ, ({n}ᶜ : Set ℕ) ∈ U)
    (R : Submodule ℝ PlufWO1.H) (T : Set ℕ)
    (hsupp : ∀ x ∈ R, ∀ n ∉ T, (x : ∀ _ : ℕ, ℝ) n = 0)
    (hbig : ∀ S ∈ U, ¬ Module.rank ℝ ↥(R ⊓ PlufWO1.block S) < ℵ₀) :
    T ∈ U := by
  sorry

/-- D3 (Baire piece-spread; Paper IV, Lemma 6.3). If `R` is closed with
    `R ⊓ W A = ⊥` and `R ⊓ block S` is infinite-dimensional (as a closed
    subspace of `H`), then it contains a vector whose piece-spread
    `{k | ∃ n ∈ A k, x n ≠ 0}` is infinite.

    Route (paper): inside the complete space `R ⊓ block S`, the vectors
    of piece-spread inside a fixed finite `F` form
    `R ⊓ block S ⊓ block (⋃ k ∈ F, A k)`, closed of finite rank by D1,
    hence a proper closed subspace with empty interior
    (`Submodule.eq_top_of_nonempty_interior'` or kin); the finite-spread
    vectors are the countable union over `F : Finset ℕ`, and Baire
    category (`BaireSpace` for the complete normed space, or the dense-
    `Gδ` formulation) leaves a vector outside. A vector of infinite
    piece-spread supported in `S` also requires `hcover`-type
    normalization of the pieces; take the partition to cover ℕ as in the
    standing setting, so spread is well-defined. -/
theorem baire_spread (A : ℕ → Set ℕ)
    (hdisj : Pairwise (Function.onFun Disjoint A))
    (hcover : (⋃ k, A k) = univ)
    (R : Submodule ℝ PlufWO1.H) (hRcl : IsClosed (R : Set PlufWO1.H))
    (hRW : R ⊓ PlufWO1.W A = ⊥) (S : Set ℕ)
    (hbig : ¬ Module.rank ℝ ↥(R ⊓ PlufWO1.block S) < ℵ₀) :
    ∃ x ∈ R ⊓ PlufWO1.block S, {k | ∃ n ∈ A k, (x : ∀ _ : ℕ, ℝ) n ≠ 0}.Infinite := by
  sorry

end Blockers

/-! ### Axiom audit for the WO-4 contract theorems
(The WO-1/WO-2/WO-3 audits run via the import chain.) -/

#print axioms inj_on_pairs               -- A1
#print axioms mem_fubini_iff             -- B0
#print axioms triangle_mem_fubini        -- B1
#print axioms countableSmall_fubini      -- B2
#print axioms column_notMem_fubini       -- B3
#print axioms fullSelector_of_fodor      -- B4
#print axioms not_fullSelector_fubini    -- B5
#print axioms fullSelector_map_iff       -- B6
#print axioms fubini_not_iso_fodor       -- B7
#print axioms sigmaQ_fubini              -- B8
#print axioms sigmaQ_of_EPP              -- C1
#print axioms EPP_fubini                 -- C2
#print axioms exact_paving_of_EPP        -- C3
#print axioms exact_dichotomy_of_EPP     -- C4
#print axioms quadratic_flat_of_EPP      -- C5
#print axioms PhiU_decides_of_EPP        -- C6
#print axioms product_decides            -- C7
#print axioms gen_thin                   -- D1
#print axioms inter_infinite_iff_mem     -- D2a
#print axioms rank_le_of_le_block_finite -- D2b
#print axioms support_mem                -- D2
#print axioms baire_spread               -- D3

end PlufWO4
