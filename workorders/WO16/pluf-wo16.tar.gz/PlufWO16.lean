/-
  PlufWO16.lean — Work Order 16 for the pluf project (Feldman, Wilce).

  Scope: the verifiable core of Paper V ("Support families of closed subspaces
  of ℓ², with an application to diagonalizable projection filters"):
    (A) support families and closure under unions — Lemma 2.1,
        Proposition 2.2, Corollary 2.3 — and the elimination property,
        Proposition 3.2;
    (B) the diagonal block: the families D(M) and I(M), the trace formula,
        diagonal consistency, and the covering criterion — Section 7;
    (C) the transfers to the series: intimacy is the covering condition at
        level three, the collapse on plufs, the covering number of Gowers's
        subspace, and the constraint on addable blockers — Section 8.

  Sections 4-6 of the paper (scrawl axioms, the finite-rank classification
  through the theorem of Aroca et al., and the model-space example) are NOT
  contracted; see the census gate below.

  A NOTE ON SCALARS. Paper V is stated over ℂ, because its finite-rank
  classification is representability and the theorem it invokes is
  field-sensitive. Everything contracted here is field-blind, and the paper
  says so in its conventions: Sections 7 and 8 use no property of the scalars.
  This work order therefore mechanizes over ℝ, against the existing
  development, and the paper's verification section will record that the
  mechanized statements are the real instances of field-blind theorems. If any
  item below turns out to need a property of ℝ, that is a finding — REPORT it.

  Base: the v1.0 release tree (243 theorems; CI runs #1-#14). `PlufWO16.lean`
  imports `RequestProject.PlufWO15`. All prior theorems must remain green;
  `PlufWO7a.lean` is the census record and is not to be edited.

  Toolchain: leanprover/lean4:v4.28.0, Mathlib pinned as in the repo.
-/
import RequestProject.PlufWO15

open Set

namespace PlufWO16

abbrev H := PlufWO1.H

/-! ### Part A: support families and unions -/

/-- The support of a vector of `ℓ²(ℕ)`. Reconcile with `PlufWO2.supp`, which is
    stated for `Hk`; if the two agree definitionally at the standard space,
    reuse rather than redefine, and REPORT. -/
def supp (x : H) : Set ℕ := {n | (x : ∀ _ : ℕ, ℝ) n ≠ 0}

/-- A1 (Paper V, Lemma 2.1). For `x, y` in a submodule `M`, some vector of `M`
    has support exactly `supp x ∪ supp y`.

    Proof: for each `n` with `y n ≠ 0` the scalar `-(x n)/(y n)` is the unique
    bad value of `λ`; countably many coordinates, uncountably many scalars, so
    some `λ ≠ 0` avoids all of them and `supp (x + λ • y) = supp x ∪ supp y`.
    In Lean the counting step is the assertion that a countable set of reals is
    not all of ℝ (`Set.Countable.ne_univ` or via `Cardinal`); pick `λ` outside
    it and nonzero. -/
theorem exists_supp_union (M : Submodule ℝ H) (x y : H) (hx : x ∈ M) (hy : y ∈ M) :
    ∃ z ∈ M, supp z = supp x ∪ supp y := by
  sorry

/-- A2 (Paper V, Proposition 2.2; the one place closedness enters). For a
    closed submodule `M` and a sequence in `M`, some vector of `M` has support
    exactly the union of their supports.

    Proof (paper): normalize `‖x i‖ = 1`, so `‖x i‖_∞ ≤ 1`. Choose `c i ≠ 0`
    recursively with `|c i| ≤ 2 ^ (-i)`; writing `s m = ∑_{i ≤ m} c i • x i`,
    at stage `m` require of `c m` that it avoid the countably many values
    killing a coordinate of `s (m-1) + c • x m`, and then freeze
    `δ m = min {|s m n| : n ≤ m, s m n ≠ 0} > 0` (a minimum over a finite set)
    by demanding `|c i| ≤ 2 ^ (-(i-m)-1) * δ m` for all `i > m`. Summability
    gives convergence; `M` closed gives membership. Each coordinate in some
    `supp (x m)` is bounded below by half its frozen value, so survives.

    The recursion is the substance. A dependent-choice gadget in the style of
    `PlufWO14.exists_seq_of_step` may serve, but note the stage constraint here
    refers to the accumulated partial sum, not only to earlier terms; report
    the shape used. -/
theorem exists_supp_iUnion (M : Submodule ℝ H) (hM : IsClosed (M : Set H))
    (x : ℕ → H) (hx : ∀ i, x i ∈ M) :
    ∃ z ∈ M, supp z = ⋃ i, supp (x i) := by
  sorry

/-- A3 (Paper V, Corollary 2.3). The support family of a closed submodule is
    closed under arbitrary unions, and its total support is realized. (A subset
    of ℕ that is a union of supports is a union of countably many of them, one
    through each of its points; apply A2.) -/
theorem exists_supp_sUnion (M : Submodule ℝ H) (hM : IsClosed (M : Set H))
    (F : Set H) (hF : ∀ x ∈ F, x ∈ M) :
    ∃ z ∈ M, supp z = ⋃ x ∈ F, supp x := by
  sorry

/-- A4 (Paper V, Proposition 3.2; elimination). Let `A ≠ B` be supports of
    vectors of `M`, minimal among the nonempty supports, and `p ∈ A ∩ B`. Then
    some nonzero vector of `M` has support inside `(A ∪ B) \ {p}`.

    (Eliminate the `p`-coordinate; the result is nonzero, since vanishing would
    make the two vectors proportional and force `A = B`.) -/
theorem exists_supp_elimination (M : Submodule ℝ H) (x y : H)
    (hx : x ∈ M) (hy : y ∈ M)
    (hminx : ∀ z ∈ M, supp z ≠ ∅ → supp z ⊆ supp x → supp z = supp x)
    (hminy : ∀ z ∈ M, supp z ≠ ∅ → supp z ⊆ supp y → supp z = supp y)
    (hne : supp x ≠ supp y) {p : ℕ} (hp : p ∈ supp x ∩ supp y) :
    ∃ z ∈ M, z ≠ 0 ∧ supp z ⊆ (supp x ∪ supp y) \ {p} := by
  sorry

/-! ### Part B: the diagonal block -/

/-- The sets meeting `M` nontrivially through their block, and its complement.
    `PlufWO1.block` is the block of the standard basis. -/
def cD (M : Submodule ℝ H) : Set (Set ℕ) := {S | M ⊓ PlufWO1.block S ≠ ⊥}

def cI (M : Submodule ℝ H) : Set (Set ℕ) := {S | M ⊓ PlufWO1.block S = ⊥}

/-- B1 (Paper V, Lemma 7.2). `S ∈ cD M` exactly when `S` contains the support
    of a nonzero vector of `M`; so `cD M` is determined by the support family,
    and `cI M` is downward closed. -/
theorem mem_cD_iff (M : Submodule ℝ H) (S : Set ℕ) :
    S ∈ cD M ↔ ∃ x ∈ M, x ≠ 0 ∧ supp x ⊆ S := by
  sorry

theorem cI_downward (M : Submodule ℝ H) {S T : Set ℕ} (hS : S ∈ cI M) (hTS : T ⊆ S) :
    T ∈ cI M := by
  sorry

/-- B2 (Paper V, Proposition 7.3; the trace formula). For a pluf, the trace on
    the diagonal block is exactly the intersection of the `cD` of its members.
    The inclusion `⊆` holds for any proper filter; equality uses the maximality
    criterion `PlufWO6.maximality_criterion`. Contract both halves. -/
theorem trace_subset (π : Set (Submodule ℝ H)) (hπ : PlufWO6.IsPluf π)
    {S : Set ℕ} (hS : PlufWO1.block S ∈ π) (M : Submodule ℝ H) (hM : M ∈ π) :
    S ∈ cD M := by
  sorry

theorem mem_trace_of_forall_cD (π : Set (Submodule ℝ H)) (hπ : PlufWO6.IsPluf π)
    {S : Set ℕ} (hS : ∀ M ∈ π, S ∈ cD M) :
    PlufWO1.block S ∈ π := by
  sorry

/-- Diagonal consistency, and the finite-cover condition. The paper's covering
    number `χ(M)` is contracted here in the two forms actually used: existence
    of an ultrafilter inside `cD M`, and existence of a finite cover of ℕ by
    members of `cI M`. (A numerical `χ` is available downstream if wanted;
    the propositional forms avoid `ℕ∞` arithmetic. REPORT if a numerical
    version proves more convenient for Part C.) -/
def DiagonallyConsistent (M : Submodule ℝ H) : Prop :=
  ∃ U : Ultrafilter ℕ, ∀ S ∈ U, S ∈ cD M

def HasFiniteCover (M : Submodule ℝ H) : Prop :=
  ∃ F : Finset (Set ℕ), (∀ S ∈ F, S ∈ cI M) ∧ (⋃ S ∈ F, S) = univ

/-- B3 (Paper V, Proposition 7.5). `M` is diagonally consistent exactly when it
    lies in a pluf whose trace is an ultrafilter.

    Forward: the finite meets of `{M} ∪ {block S : S ∈ U}` are
    `M ⊓ block (S₁ ∩ ⋯ ∩ S_k)`, nonzero since the intersection lies in `U`; so
    the generated filter is proper, and any pluf extending it has trace
    containing `U`, hence equal to `U`, a trace containing no complementary
    pair. Backward is B2. -/
theorem diagonallyConsistent_iff (M : Submodule ℝ H) (hM : IsClosed (M : Set H)) :
    DiagonallyConsistent M ↔
      ∃ π, PlufWO6.IsPluf π ∧ M ∈ π ∧
        ∃ U : Ultrafilter ℕ, ∀ S : Set ℕ, S ∈ U ↔ PlufWO1.block S ∈ π := by
  sorry

/-- B4 (Paper V, Theorem 7.6; the covering criterion). `M` is diagonally
    consistent if and only if ℕ admits no finite cover by members of `cI M`.

    Forward: primeness of the ultrafilter would place a cover piece in
    `U ⊆ cD M`. Backward: the finite unions of members of `cI M` form a proper
    ideal (this is the hypothesis), so its dual filter extends to an
    ultrafilter disjoint from `cI M`. -/
theorem diagonallyConsistent_iff_not_finiteCover (M : Submodule ℝ H) :
    DiagonallyConsistent M ↔ ¬ HasFiniteCover M := by
  sorry

/-! ### Part C: transfers to the series -/

/-- C1 (Paper V, Proposition 8.1). `M` is intimate for the standard basis
    exactly when ℕ is not the union of two members of `cI M` — the covering
    condition at level three. Use `PlufWO5.Intimate`; if `PlufWO10.IntimateB`
    at the standard basis is the more convenient form, use it and cite
    `PlufWO10.intimateB_stdHilbertBasis_iff`. -/
theorem intimate_iff_no_two_cover (M : Submodule ℝ H) :
    PlufWO5.Intimate M ↔ ¬ ∃ S T : Set ℕ, S ∈ cI M ∧ T ∈ cI M ∧ S ∪ T = univ := by
  sorry

/-- C2 (Paper V, Proposition 8.2; the collapse). Every member of a pluf whose
    trace is an ultrafilter is diagonally consistent. -/
theorem diagonallyConsistent_of_mem_diagonalizable
    (π : Set (Submodule ℝ H)) (hπ : PlufWO6.IsPluf π)
    (U : Ultrafilter ℕ) (hU : ∀ S : Set ℕ, S ∈ U ↔ PlufWO1.block S ∈ π)
    (M : Submodule ℝ H) (hM : M ∈ π) :
    DiagonallyConsistent M := by
  sorry

/-- C3 (Paper V, Corollary 8.3). For a nonprincipal pluf, "every member
    intimate" and "every member diagonally consistent" agree; both are
    diagonalizability. Assemble C1, C2 and
    `PlufWO6.diagonalizable_iff_intimate_pluf`. -/
theorem diagonalizable_iff_all_diagonallyConsistent
    (π : Set (Submodule ℝ H)) (hπ : PlufWO6.IsPluf π)
    (hnp : ∀ v : H, v ≠ 0 → ∃ N ∈ π, v ∉ N) :
    (∃ U : Ultrafilter ℕ, ∀ S : Set ℕ, S ∈ U ↔ PlufWO1.block S ∈ π) ↔
      (∀ M ∈ π, DiagonallyConsistent M) := by
  sorry

/-! #### Gowers's subspace

`PlufWO5.gowersX` is the joint kernel of the duplicated constraints. In the
development's 0-indexing the pairs are `{2k, 2k+1}`; the paper displays them
1-indexed. Reconcile once, at the statement of C4, and REPORT the convention
used. -/

/-- The `k`-th coordinate pair. -/
def pair (k : ℕ) : Set ℕ := {2 * k, 2 * k + 1}

/-- C4a (the membership recursion). A vector lies in `gowersX` exactly when its
    sequence of pair sums `s k = x (2k) + x (2k+1)` satisfies the recursion
    carried by the constraint vectors. State it in whichever form
    `PlufWO5/PartD.lean` already supports — `PlufWO5.gowersX_pairSum_eq_zero`
    proves the finitely supported case, and its engine is this recursion;
    extract and export the general form. -/
theorem gowersX_pairSum_rec {x : H} (hx : x ∈ PlufWO5.gowersX) (k : ℕ) :
    True := by
  sorry

/-- C4b (the independent sets). `S ∈ cI gowersX` exactly when `S` contains no
    complete pair and misses some pair entirely.

    (⇐) A vector supported in such an `S` has a vanishing pair sum at the
    missed pair, so by the recursion all pair sums vanish; then each pair
    contributes `x (2k) = - x (2k+1)` with at most one of the two coordinates
    available, forcing both to vanish.
    (⇒) If `S ⊇ pair k` then `e (2k) - e (2k+1)` lies in the meet; if `S` meets
    every pair, the vector with `x (a k) = 1/(k+1)` at the chosen point of each
    pair has pair sums `1/(k+1)`, which satisfy the recursion, and lies in the
    meet. -/
theorem mem_cI_gowersX_iff (S : Set ℕ) :
    S ∈ cI PlufWO5.gowersX ↔
      (∀ k, ¬ pair k ⊆ S) ∧ (∃ j, Disjoint (pair j) S) := by
  sorry

/-- C4 (Paper V, Theorem 8.4). Gowers's subspace admits a cover of ℕ by three
    independent sets, and none by two; so it is intimate and not diagonally
    consistent, and belongs to no pluf with ultrafilter trace.

    For the three-cover: assign the two coordinates of each pair to two
    distinct classes among three, arranging that pair `0` avoids class `2`,
    pair `1` avoids class `0`, and pair `2` avoids class `1`. Each class then
    contains no complete pair and misses a pair. Intimacy is
    `PlufWO5.gowersX_intimate`. -/
theorem gowersX_threeCover :
    (∃ S T V : Set ℕ, S ∈ cI PlufWO5.gowersX ∧ T ∈ cI PlufWO5.gowersX ∧
      V ∈ cI PlufWO5.gowersX ∧ S ∪ T ∪ V = univ) ∧
    ¬ DiagonallyConsistent PlufWO5.gowersX := by
  sorry

/-- C5 (Paper V, Proposition 8.5). An addable blocker of a witness subspace is
    diagonally consistent. (Infinite-dimensional intersection with every
    `block S`, `S ∈ U`, gives in particular a nonzero intersection.) This is a
    fourth constraint on the rigidity conjecture, independent of the three in
    `PlufWO4/Blockers.lean`. -/
theorem diagonallyConsistent_of_addableBlocker (U : Ultrafilter ℕ)
    (R : Submodule ℝ H)
    (hR : ∀ S ∈ U, ¬ Module.Finite ℝ ↥(R ⊓ PlufWO1.block S)) :
    DiagonallyConsistent R := by
  sorry

/-! ### Axiom audit -/

#print axioms exists_supp_union
#print axioms exists_supp_iUnion
#print axioms exists_supp_sUnion
#print axioms exists_supp_elimination
#print axioms mem_cD_iff
#print axioms cI_downward
#print axioms trace_subset
#print axioms mem_trace_of_forall_cD
#print axioms diagonallyConsistent_iff
#print axioms diagonallyConsistent_iff_not_finiteCover
#print axioms intimate_iff_no_two_cover
#print axioms diagonallyConsistent_of_mem_diagonalizable
#print axioms diagonalizable_iff_all_diagonallyConsistent
#print axioms mem_cI_gowersX_iff
#print axioms gowersX_threeCover
#print axioms diagonallyConsistent_of_addableBlocker

end PlufWO16
